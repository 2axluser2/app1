const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const db = require('./db');

// Initialize express app
const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Status endpoint for health checks
app.get('/status', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// User routes
app.get('/api/users/:username', async (req, res) => {
  try {
    const { username } = req.params;
    const result = await db.query('SELECT id, username, email, created_at FROM users WHERE username = $1', [username]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Contact routes
app.get('/api/users/:userId/contacts', async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await db.query(
      'SELECT id, name, phone, relationship, created_at FROM contacts WHERE user_id = $1 ORDER BY name',
      [userId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/users/:userId/contacts', async (req, res) => {
  try {
    const { userId } = req.params;
    const { name, phone, relationship } = req.body;
    
    if (!name || !phone) {
      return res.status(400).json({ error: 'Name and phone are required' });
    }
    
    const result = await db.query(
      'INSERT INTO contacts (user_id, name, phone, relationship) VALUES ($1, $2, $3, $4) RETURNING *',
      [userId, name, phone, relationship || null]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error adding contact:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/contacts/:contactId', async (req, res) => {
  try {
    const { contactId } = req.params;
    
    const result = await db.query('DELETE FROM contacts WHERE id = $1 RETURNING *', [contactId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }
    
    res.json({ message: 'Contact deleted successfully' });
  } catch (error) {
    console.error('Error deleting contact:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Alert routes
app.post('/api/users/:userId/alerts', async (req, res) => {
  try {
    const { userId } = req.params;
    const { message, triggerType, locationLat, locationLong, contactIds } = req.body;
    
    // Create the alert
    const alertResult = await db.query(
      'INSERT INTO alerts (user_id, message, trigger_type, location_lat, location_long) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [userId, message, triggerType, locationLat || null, locationLong || null]
    );
    
    const alertId = alertResult.rows[0].id;
    
    // Get contacts (either specified or all)
    let contacts = [];
    if (contactIds && contactIds.length > 0) {
      const contactsResult = await db.query(
        'SELECT id FROM contacts WHERE id = ANY($1::int[]) AND user_id = $2',
        [contactIds, userId]
      );
      contacts = contactsResult.rows;
    } else {
      const contactsResult = await db.query(
        'SELECT id FROM contacts WHERE user_id = $1',
        [userId]
      );
      contacts = contactsResult.rows;
    }
    
    // Create alert recipients
    for (const contact of contacts) {
      await db.query(
        'INSERT INTO alert_recipients (alert_id, contact_id) VALUES ($1, $2)',
        [alertId, contact.id]
      );
    }
    
    // Get the full alert with recipients
    const fullAlertResult = await db.query(
      `SELECT a.*, 
        json_agg(json_build_object('id', c.id, 'name', c.name, 'phone', c.phone)) as recipients
      FROM alerts a
      LEFT JOIN alert_recipients ar ON a.id = ar.alert_id
      LEFT JOIN contacts c ON ar.contact_id = c.id
      WHERE a.id = $1
      GROUP BY a.id`,
      [alertId]
    );
    
    res.status(201).json(fullAlertResult.rows[0]);
  } catch (error) {
    console.error('Error creating alert:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/users/:userId/alerts', async (req, res) => {
  try {
    const { userId } = req.params;
    const result = await db.query(
      `SELECT a.*, 
        json_agg(json_build_object('id', c.id, 'name', c.name, 'phone', c.phone)) as recipients
      FROM alerts a
      LEFT JOIN alert_recipients ar ON a.id = ar.alert_id
      LEFT JOIN contacts c ON ar.contact_id = c.id
      WHERE a.user_id = $1
      GROUP BY a.id
      ORDER BY a.created_at DESC`,
      [userId]
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching alerts:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Initialize database
async function initializeDatabase() {
  try {
    const schemaFile = path.join(__dirname, 'schema.sql');
    const schema = fs.readFileSync(schemaFile, 'utf8');
    await db.query(schema);
    console.log('Database schema initialized successfully.');
  } catch (error) {
    console.error('Error initializing database schema:', error);
  }
}

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
  initializeDatabase();
});