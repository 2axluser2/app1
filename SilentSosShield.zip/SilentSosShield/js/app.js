document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();

    // DOM elements - General
    const configForm = document.getElementById('configForm');
    const alertMessageInput = document.getElementById('alertMessage');
    const contactForm = document.getElementById('contactForm');
    const contactNameInput = document.getElementById('contactName');
    const contactPhoneInput = document.getElementById('contactPhone');
    const contactList = document.getElementById('contactList');
    const alertStatus = document.getElementById('alertStatus');
    const sosModal = new bootstrap.Modal(document.getElementById('sosModal'));
    const sentMessage = document.getElementById('sentMessage');
    const sentContacts = document.getElementById('sentContacts');
    
    // DOM elements - Power Button
    const pressCountInput = document.getElementById('pressCount');
    const pressCountDisplay = document.getElementById('pressCountDisplay');
    const powerButton = document.getElementById('powerButton');
    const pressIndicator = document.getElementById('pressIndicator');
    const progressBarButton = pressIndicator.querySelector('.progress-bar');
    const testPressCount = document.getElementById('testPressCount');
    
    // DOM elements - Gesture Settings
    const gesturesEnabledInput = document.getElementById('gesturesEnabled');
    const shakeEnabledInput = document.getElementById('shakeEnabled');
    const tiltEnabledInput = document.getElementById('tiltEnabled');
    const shakeThresholdInput = document.getElementById('shakeThreshold');
    const shakeThresholdDisplay = document.getElementById('shakeThresholdDisplay');
    const shakeCountInput = document.getElementById('shakeCount');
    const shakeCountDisplay = document.getElementById('shakeCountDisplay');
    const tiltThresholdInput = document.getElementById('tiltThreshold');
    const tiltThresholdDisplay = document.getElementById('tiltThresholdDisplay');
    const tiltHoldTimeInput = document.getElementById('tiltHoldTime');
    const tiltHoldTimeDisplay = document.getElementById('tiltHoldTimeDisplay');
    const gestureSettingsPanel = document.getElementById('gestureSettings');
    
    // DOM elements - Gesture Testing
    const gestureToggleBtn = document.getElementById('gestureToggleBtn');
    const simulateShakeBtn = document.getElementById('simulateShakeBtn');
    const simulateTiltBtn = document.getElementById('simulateTiltBtn');
    const sensorStatus = document.getElementById('sensorStatus');
    const gestureIndicator = document.getElementById('gestureIndicator');
    const progressBarGesture = gestureIndicator.querySelector('.progress-bar');
    
    // DOM elements - Voice Detection
    const voiceEnabledInput = document.getElementById('voiceEnabled');
    const voiceConfidenceInput = document.getElementById('voiceConfidence');
    const voiceConfidenceDisplay = document.getElementById('voiceConfidenceDisplay');
    const voiceLanguageInput = document.getElementById('voiceLanguage');
    const phrasesList = document.getElementById('phrasesList');
    const newPhraseInput = document.getElementById('newPhraseInput');
    const addPhraseBtn = document.getElementById('addPhraseBtn');
    const testVoiceBtn = document.getElementById('testVoiceBtn');
    const voiceStatus = document.getElementById('voiceStatus');
    const voiceIndicator = document.getElementById('voiceIndicator');
    const voiceSettingsPanel = document.getElementById('voiceSettings');
    
    // Voice testing elements
    const voiceToggleBtn = document.getElementById('voiceToggleBtn');
    const microphoneStatus = document.getElementById('microphoneStatus');
    const currentPhrases = document.getElementById('currentPhrases');
    const testPhraseSelect = document.getElementById('testPhraseSelect');
    const simulateVoiceBtn = document.getElementById('simulateVoiceBtn');
    const voiceProgressIndicator = document.getElementById('voiceProgressIndicator');
    const progressBarVoice = voiceProgressIndicator.querySelector('.progress-bar');

    // Initialize form values from config
    
    // Power button settings
    pressCountInput.value = configManager.getPressCount();
    pressCountDisplay.textContent = configManager.getPressCount();
    testPressCount.textContent = configManager.getPressCount();
    alertMessageInput.value = configManager.getAlertMessage();
    
    // Gesture settings
    const gestureSettings = configManager.getGestureSettings();
    gesturesEnabledInput.checked = gestureSettings.enabled;
    shakeEnabledInput.checked = gestureSettings.shakeEnabled;
    tiltEnabledInput.checked = gestureSettings.tiltEnabled;
    shakeThresholdInput.value = gestureSettings.shakeThreshold;
    shakeThresholdDisplay.textContent = gestureSettings.shakeThreshold;
    shakeCountInput.value = gestureSettings.shakeCount;
    shakeCountDisplay.textContent = gestureSettings.shakeCount;
    tiltThresholdInput.value = gestureSettings.tiltThreshold;
    tiltThresholdDisplay.textContent = gestureSettings.tiltThreshold;
    tiltHoldTimeInput.value = gestureSettings.tiltHoldTime;
    tiltHoldTimeDisplay.textContent = (gestureSettings.tiltHoldTime / 1000) + 's';
    
    // Update UI based on gesture enabled state
    updateGestureSettingsUI();

    // Voice settings
    const voiceSettings = configManager.getVoiceSettings();
    voiceEnabledInput.checked = voiceSettings.enabled;
    voiceConfidenceInput.value = voiceSettings.confidenceThreshold;
    voiceConfidenceDisplay.textContent = voiceSettings.confidenceThreshold;
    voiceLanguageInput.value = voiceSettings.language;
    
    // Update UI based on voice enabled state
    updateVoiceSettingsUI();
    
    // Render voice phrases
    renderVoicePhrases();
    renderTestPhrasesSelect();
    
    // AI Threat Detection settings
    const aiSettings = configManager.getAIThreatSettings();
    aiThreatEnabled.checked = aiSettings.enabled;
    autoTriggerEnabled.checked = aiSettings.automaticTrigger;
    
    // Sensor usage
    useAccelerometer.checked = aiSettings.sensors.useAccelerometer;
    useHeartRate.checked = aiSettings.sensors.useHeartRate;
    useAudio.checked = aiSettings.sensors.useAudio;
    
    // Thresholds
    threatLevelThreshold.value = aiSettings.thresholds.threatLevel;
    threatLevelDisplay.textContent = aiSettings.thresholds.threatLevel;
    
    heartRateThreshold.value = aiSettings.thresholds.heartRateElevation;
    heartRateThresholdDisplay.textContent = aiSettings.thresholds.heartRateElevation + '%';
    
    audioThreshold.value = aiSettings.thresholds.audioSpike;
    audioThresholdDisplay.textContent = aiSettings.thresholds.audioSpike + 'x';
    
    // Predictive Learning settings
    const predictiveSettings = configManager.getPredictiveLearningSettings();
    predictiveLearningEnabled.checked = predictiveSettings.enabled;
    
    anomalyThreshold.value = predictiveSettings.anomalyThreshold;
    anomalyThresholdDisplay.textContent = predictiveSettings.anomalyThreshold;
    
    learningRate.value = predictiveSettings.learningRate;
    learningRateDisplay.textContent = predictiveSettings.learningRate;
    
    considerTimeOfDay.checked = predictiveSettings.considerTimeOfDay;
    considerDayOfWeek.checked = predictiveSettings.considerDayOfWeek;
    considerLocation.checked = predictiveSettings.considerLocation;
    
    // Update UI based on AI threat enabled state
    updateAIThreatSettingsUI();
    
    // Update SOS trigger with current press count
    sosTrigger.setPressCount(configManager.getPressCount());
    
    // Update gesture detector settings
    updateGestureDetectorSettings();

    // Load contacts
    renderContacts();
    
    // Set up gesture detector event listeners
    document.addEventListener('gesturedetectorerror', function(e) {
        showAlert('Gesture Detector Error: ' + e.detail.message, 'danger');
    });

    //============= POWER BUTTON HANDLING =============//
    
    // Update press count display when slider is moved
    pressCountInput.addEventListener('input', function() {
        pressCountDisplay.textContent = this.value;
        testPressCount.textContent = this.value;
    });

    // Simulate power button press
    powerButton.addEventListener('click', function() {
        sosTrigger.registerPress();
        powerButton.classList.add('sos-animation');
        setTimeout(() => {
            powerButton.classList.remove('sos-animation');
        }, 300);
    });

    // Set up SOS trigger callbacks
    sosTrigger.setOnProgress((progress, current, total) => {
        // Update progress bar
        progressBarButton.style.width = `${progress}%`;
        progressBarButton.setAttribute('aria-valuenow', progress);
    });

    sosTrigger.setOnReset(() => {
        // Reset progress bar
        progressBarButton.style.width = '0%';
        progressBarButton.setAttribute('aria-valuenow', 0);
        alertStatus.classList.add('d-none');
    });

    sosTrigger.setOnTrigger(async () => {
        showTriggeredStatus('Power Button');
    });

    //============= GESTURE HANDLING =============//
    
    // Handle gesture enable/disable toggle
    gesturesEnabledInput.addEventListener('change', function() {
        configManager.setGesturesEnabled(this.checked);
        updateGestureSettingsUI();
    });
    
    // Handle shake detection enable/disable
    shakeEnabledInput.addEventListener('change', function() {
        configManager.setShakeEnabled(this.checked);
    });
    
    // Handle tilt detection enable/disable
    tiltEnabledInput.addEventListener('change', function() {
        configManager.setTiltEnabled(this.checked);
    });
    
    // Update shake threshold display
    shakeThresholdInput.addEventListener('input', function() {
        shakeThresholdDisplay.textContent = this.value;
    });
    
    // Update shake count display
    shakeCountInput.addEventListener('input', function() {
        shakeCountDisplay.textContent = this.value;
    });
    
    // Update tilt threshold display
    tiltThresholdInput.addEventListener('input', function() {
        tiltThresholdDisplay.textContent = this.value;
    });
    
    // Update tilt hold time display
    tiltHoldTimeInput.addEventListener('input', function() {
        const seconds = (this.value / 1000).toFixed(1);
        tiltHoldTimeDisplay.textContent = seconds + 's';
    });
    
    // Toggle gesture detection on/off
    let gestureDetectionActive = false;
    gestureToggleBtn.addEventListener('click', function() {
        if (gestureDetectionActive) {
            // Stop detection
            gestureDetector.stopListening();
            gestureDetectionActive = false;
            gestureToggleBtn.textContent = 'Start Detection';
            gestureToggleBtn.classList.remove('btn-danger');
            gestureToggleBtn.classList.add('btn-success');
            sensorStatus.textContent = 'Gesture detection stopped.';
            simulateShakeBtn.disabled = true;
            simulateTiltBtn.disabled = true;
            progressBarGesture.style.width = '0%';
        } else {
            // Start detection
            gestureDetector.startListening();
            gestureDetectionActive = true;
            gestureToggleBtn.textContent = 'Stop Detection';
            gestureToggleBtn.classList.remove('btn-success');
            gestureToggleBtn.classList.add('btn-danger');
            sensorStatus.textContent = 'Detecting motion...';
            simulateShakeBtn.disabled = false;
            simulateTiltBtn.disabled = false;
        }
    });
    
    // Set up gesture detector callbacks
    gestureDetector.setOnProgress((progress, current, total) => {
        // Update gesture progress bar
        progressBarGesture.style.width = `${progress}%`;
        progressBarGesture.setAttribute('aria-valuenow', progress);
    });
    
    gestureDetector.setOnReset(() => {
        // Reset gesture progress bar
        progressBarGesture.style.width = '0%';
        progressBarGesture.setAttribute('aria-valuenow', 0);
    });
    
    gestureDetector.setOnTrigger((triggerType) => {
        showTriggeredStatus(triggerType === 'shake' ? 'Shake' : 'Tilt');
    });
    
    // Simulate shake for testing
    simulateShakeBtn.addEventListener('click', function() {
        // Fake data to simulate multiple shakes
        for (let i = 0; i < configManager.getShakeCount(); i++) {
            setTimeout(() => {
                // Create and dispatch devicemotion event with high acceleration
                const mockEvent = {
                    accelerationIncludingGravity: {
                        x: Math.random() * 40 - 20,
                        y: Math.random() * 40 - 20,
                        z: Math.random() * 40 - 20
                    }
                };
                
                gestureDetector.handleAcceleration(mockEvent);
                
                // Force processing the data
                gestureDetector.processAccelerationData();
            }, i * 200); // Spaced out over time to simulate real shakes
        }
    });
    
    // Simulate tilt for testing
    simulateTiltBtn.addEventListener('click', function() {
        // Create and dispatch deviceorientation event with high tilt angle
        const tiltThreshold = configManager.getTiltThreshold();
        const mockEvent = {
            alpha: 0,
            beta: tiltThreshold + 5, // Exceeds the threshold
            gamma: 0
        };
        
        gestureDetector.handleOrientation(mockEvent);
        
        // Show message that user needs to hold
        sensorStatus.textContent = `Holding tilt for ${configManager.getTiltHoldTime()/1000} seconds...`;
        
        // Don't need to call processTiltData as it's handled in the event handler
    });
    
    //============= VOICE DETECTION HANDLING =============//
    
    // Initialize voice detector
    const voiceDetector = createVoiceDetector(configManager, alertService);
    
    // Handle voice detection enable/disable toggle
    voiceEnabledInput.addEventListener('change', function() {
        configManager.setVoiceEnabled(this.checked);
        updateVoiceSettingsUI();
    });
    
    // Update voice confidence threshold display
    voiceConfidenceInput.addEventListener('input', function() {
        voiceConfidenceDisplay.textContent = this.value;
    });
    
    // Add phrase button
    addPhraseBtn.addEventListener('click', function() {
        const phrase = newPhraseInput.value.trim();
        
        if (phrase) {
            try {
                configManager.addVoiceTriggerPhrase(phrase);
                renderVoicePhrases();
                renderTestPhrasesSelect();
                newPhraseInput.value = '';
                showAlert(`Added phrase "${phrase}"`, 'success');
            } catch (error) {
                showAlert(`Error: ${error.message}`, 'danger');
            }
        }
    });
    
    // New phrase input Enter key
    newPhraseInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addPhraseBtn.click();
        }
    });
    
    // Test voice detection
    let voiceDetectionActive = false;
    
    // Test voice button in settings panel
    testVoiceBtn.addEventListener('click', function() {
        if (voiceDetectionActive) {
            voiceDetector.stopListening();
            voiceDetectionActive = false;
            testVoiceBtn.textContent = 'Test Voice Detection';
            voiceStatus.textContent = 'Not Listening';
            voiceStatus.classList.remove('bg-danger');
            voiceStatus.classList.add('bg-secondary');
            voiceIndicator.classList.add('d-none');
        } else {
            if (!voiceDetector.isSupported()) {
                showAlert('Voice detection is not supported in this browser.', 'danger');
                return;
            }
            
            voiceDetector.stopListening();  // Stop if running elsewhere
            voiceDetector.startListening();
            voiceDetectionActive = true;
            testVoiceBtn.textContent = 'Stop Testing';
            voiceStatus.textContent = 'Listening...';
            voiceStatus.classList.remove('bg-secondary');
            voiceStatus.classList.add('bg-danger');
            voiceIndicator.classList.remove('d-none');
            
            showAlert('Voice detection is active. Speak a trigger phrase to test.', 'info');
        }
    });
    
    // Toggle button in test panel
    voiceToggleBtn.addEventListener('click', function() {
        if (voiceDetectionActive) {
            voiceDetector.stopListening();
            voiceDetectionActive = false;
            voiceToggleBtn.textContent = 'Start Listening';
            voiceToggleBtn.classList.remove('btn-danger');
            voiceToggleBtn.classList.add('btn-success');
            microphoneStatus.textContent = 'Voice detection stopped.';
            simulateVoiceBtn.disabled = true;
            progressBarVoice.style.width = '0%';
        } else {
            if (!voiceDetector.isSupported()) {
                showAlert('Voice detection is not supported in this browser.', 'danger');
                return;
            }
            
            // Update voice detector with current language
            voiceDetector.recognition.lang = configManager.getVoiceLanguage();
            
            voiceDetector.startListening();
            voiceDetectionActive = true;
            voiceToggleBtn.textContent = 'Stop Listening';
            voiceToggleBtn.classList.remove('btn-success');
            voiceToggleBtn.classList.add('btn-danger');
            microphoneStatus.textContent = 'Listening for voice commands...';
            simulateVoiceBtn.disabled = false;
            
            // Render current phrases in the test panel
            currentPhrases.innerHTML = '';
            configManager.getVoiceTriggerPhrases().forEach(phrase => {
                const item = document.createElement('li');
                item.className = 'list-group-item';
                item.textContent = phrase;
                currentPhrases.appendChild(item);
            });
        }
    });
    
    // Simulate voice command
    simulateVoiceBtn.addEventListener('click', function() {
        const phrase = testPhraseSelect.value;
        if (phrase) {
            progressBarVoice.style.width = '100%';
            progressBarVoice.setAttribute('aria-valuenow', 100);
            
            setTimeout(() => {
                voiceDetector.triggerSOS(phrase);
            }, 500);
        }
    });
    
    // Voice detector callbacks
    voiceDetector.setOnProgress((progress) => {
        progressBarVoice.style.width = `${progress}%`;
        progressBarVoice.setAttribute('aria-valuenow', progress);
    });
    
    voiceDetector.setOnReset(() => {
        progressBarVoice.style.width = '0%';
        progressBarVoice.setAttribute('aria-valuenow', 0);
    });
    
    voiceDetector.setOnTrigger((triggerType, phrase) => {
        showTriggeredStatus(`Voice Command: "${phrase}"`);
    });
    
    voiceDetector.setOnError((message) => {
        showAlert(`Voice Detection Error: ${message}`, 'danger');
        
        // Reset UI if there was an error
        if (voiceDetectionActive) {
            voiceDetectionActive = false;
            voiceToggleBtn.textContent = 'Start Listening';
            voiceToggleBtn.classList.remove('btn-danger');
            voiceToggleBtn.classList.add('btn-success');
            testVoiceBtn.textContent = 'Test Voice Detection';
            voiceStatus.textContent = 'Not Listening';
            voiceStatus.classList.remove('bg-danger');
            voiceStatus.classList.add('bg-secondary');
            voiceIndicator.classList.add('d-none');
            microphoneStatus.textContent = 'Voice detection error.';
            simulateVoiceBtn.disabled = true;
        }
    });
    
    //============= AI THREAT DETECTION HANDLING =============//
    
    // Initialize threat detector
    const threatDetector = createThreatDetector(configManager, alertService);
    
    // Handle AI threat detection enable/disable toggle
    aiThreatEnabled.addEventListener('change', function() {
        configManager.setAIThreatEnabled(this.checked);
        updateAIThreatSettingsUI();
    });
    
    // Handle auto-trigger enable/disable toggle
    autoTriggerEnabled.addEventListener('change', function() {
        configManager.setAutomaticTriggerEnabled(this.checked);
    });
    
    // Handle sensor usage toggles
    useAccelerometer.addEventListener('change', function() {
        configManager.updateAIThreatSensors({
            useAccelerometer: this.checked
        });
    });
    
    useHeartRate.addEventListener('change', function() {
        configManager.updateAIThreatSensors({
            useHeartRate: this.checked
        });
    });
    
    useAudio.addEventListener('change', function() {
        configManager.updateAIThreatSensors({
            useAudio: this.checked
        });
    });
    
    // Update threshold displays
    threatLevelThreshold.addEventListener('input', function() {
        threatLevelDisplay.textContent = this.value;
    });
    
    heartRateThreshold.addEventListener('input', function() {
        heartRateThresholdDisplay.textContent = this.value + '%';
    });
    
    audioThreshold.addEventListener('input', function() {
        audioThresholdDisplay.textContent = this.value + 'x';
    });
    
    // Toggle AI threat detection on/off
    let threatDetectionActive = false;
    threatToggleBtn.addEventListener('click', function() {
        if (threatDetectionActive) {
            // Stop detection
            threatDetector.stop();
            threatDetectionActive = false;
            threatToggleBtn.textContent = 'Start Monitoring';
            threatToggleBtn.classList.remove('btn-danger');
            threatToggleBtn.classList.add('btn-success');
            threatStatus.textContent = 'AI threat detection is inactive. Click "Start Monitoring" to enable.';
            simulateRunBtn.disabled = true;
            simulateAttackBtn.disabled = true;
            simulateAccidentBtn.disabled = true;
            threatLevelBar.style.width = '0%';
            threatLevelBar.setAttribute('aria-valuenow', 0);
            threatLevelValue.textContent = '0';
            threatLevelBar.classList.remove('bg-warning', 'bg-danger');
            threatLevelBar.classList.add('bg-success');
        } else {
            // Update threat detector with current settings
            updateThreatDetectorSettings();
            
            // Start detection
            threatDetector.start();
            threatDetectionActive = true;
            threatToggleBtn.textContent = 'Stop Monitoring';
            threatToggleBtn.classList.remove('btn-success');
            threatToggleBtn.classList.add('btn-danger');
            threatStatus.textContent = 'AI threat detection active. Monitoring for dangerous situations...';
            simulateRunBtn.disabled = false;
            simulateAttackBtn.disabled = false;
            simulateAccidentBtn.disabled = false;
        }
    });
    
    // Set up threat detector callbacks
    threatDetector.setOnProgress((threatLevel, components) => {
        // Update threat level display
        threatLevelValue.textContent = threatLevel;
        threatLevelBar.style.width = `${threatLevel}%`;
        threatLevelBar.setAttribute('aria-valuenow', threatLevel);
        
        // Update progress bar color based on threat level
        if (threatLevel < 30) {
            threatLevelBar.classList.remove('bg-warning', 'bg-danger');
            threatLevelBar.classList.add('bg-success');
        } else if (threatLevel < 70) {
            threatLevelBar.classList.remove('bg-success', 'bg-danger');
            threatLevelBar.classList.add('bg-warning');
        } else {
            threatLevelBar.classList.remove('bg-success', 'bg-warning');
            threatLevelBar.classList.add('bg-danger');
        }
        
        // Update progress bar in the test tab
        threatProgressIndicator.querySelector('.progress-bar').style.width = `${threatLevel}%`;
        threatProgressIndicator.querySelector('.progress-bar').setAttribute('aria-valuenow', threatLevel);
        
        // Update sensor readings
        movementTypeValue.textContent = threatDetector.movementType.charAt(0).toUpperCase() + 
                                         threatDetector.movementType.slice(1);
        heartRateValue.textContent = threatDetector.heartRate;
        
        // Calculate heart rate elevation
        if (threatDetector.heartRateBaseline > 0) {
            const elevation = Math.round((threatDetector.heartRate - threatDetector.heartRateBaseline) / 
                                          threatDetector.heartRateBaseline * 100);
            heartRateElevationValue.textContent = elevation > 0 ? `+${elevation}` : elevation;
        } else {
            heartRateElevationValue.textContent = 'N/A';
        }
        
        // Update audio levels
        audioLevelValue.textContent = Math.round(threatDetector.audioLevel);
        
        if (threatDetector.environmentBaseline.audio > 0) {
            const audioSpike = (threatDetector.audioLevel / threatDetector.environmentBaseline.audio).toFixed(1);
            audioSpikeValue.textContent = audioSpike + 'x';
        } else {
            audioSpikeValue.textContent = 'N/A';
        }
    });
    
    threatDetector.setOnReset(() => {
        // Reset threat level displays
        threatLevelValue.textContent = '0';
        threatLevelBar.style.width = '0%';
        threatLevelBar.setAttribute('aria-valuenow', 0);
        threatLevelBar.classList.remove('bg-warning', 'bg-danger');
        threatLevelBar.classList.add('bg-success');
        
        // Reset progress bar
        threatProgressIndicator.querySelector('.progress-bar').style.width = '0%';
        threatProgressIndicator.querySelector('.progress-bar').setAttribute('aria-valuenow', 0);
    });
    
    threatDetector.setOnTrigger((triggerType, context) => {
        // Show context in threat status
        threatStatus.innerHTML = `<strong>THREAT DETECTED!</strong> Movement: ${context.movementType}, Heart Rate: ${context.heartRate} bpm (${context.heartRateElevation}% elevation), Audio: ${context.audioLevel} (${context.audioElevation}x normal)`;
        
        showTriggeredStatus(`AI Threat Detection`);
    });
    
    threatDetector.setOnError((message) => {
        showAlert(`AI Threat Detection Error: ${message}`, 'danger');
        
        // Reset UI if there was an error
        if (threatDetectionActive) {
            threatDetectionActive = false;
            threatToggleBtn.textContent = 'Start Monitoring';
            threatToggleBtn.classList.remove('btn-danger');
            threatToggleBtn.classList.add('btn-success');
            threatStatus.textContent = 'AI threat detection error. Please try again.';
            simulateRunBtn.disabled = true;
            simulateAttackBtn.disabled = true;
            simulateAccidentBtn.disabled = true;
        }
    });
    
    // Simulation buttons
    simulateRunBtn.addEventListener('click', function() {
        threatDetector.simulateThreatScenario('running');
        threatStatus.textContent = 'Simulating running scenario...';
    });
    
    simulateAttackBtn.addEventListener('click', function() {
        threatDetector.simulateThreatScenario('attack');
        threatStatus.textContent = 'Simulating attack scenario...';
    });
    
    simulateAccidentBtn.addEventListener('click', function() {
        threatDetector.simulateThreatScenario('accident');
        threatStatus.textContent = 'Simulating accident scenario...';
    });
    
    /**
     * Updates the threat detector settings with values from config
     */
    function updateThreatDetectorSettings() {
        const settings = configManager.getAIThreatSettings();
        
        // Update the threat detector with current settings
        threatDetector.updateSettings({
            thresholds: settings.thresholds,
            sensors: settings.sensors,
            weights: settings.weights
        });
    }
    
    //============= FORM SUBMISSIONS =============//

    // Save configuration on form submit
    configForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        try {
            // Update power button configuration
            configManager.setPressCount(parseInt(pressCountInput.value));
            configManager.setAlertMessage(alertMessageInput.value);
            
            // Update gesture configuration
            configManager.setGesturesEnabled(gesturesEnabledInput.checked);
            configManager.setShakeEnabled(shakeEnabledInput.checked);
            configManager.setTiltEnabled(tiltEnabledInput.checked);
            configManager.setShakeThreshold(parseInt(shakeThresholdInput.value));
            configManager.setShakeCount(parseInt(shakeCountInput.value));
            configManager.setTiltThreshold(parseInt(tiltThresholdInput.value));
            configManager.setTiltHoldTime(parseInt(tiltHoldTimeInput.value));
            
            // Update voice configuration
            configManager.setVoiceEnabled(voiceEnabledInput.checked);
            configManager.setVoiceConfidenceThreshold(parseFloat(voiceConfidenceInput.value));
            configManager.setVoiceLanguage(voiceLanguageInput.value);
            
            // Update AI threat detection configuration
            configManager.setAIThreatEnabled(aiThreatEnabled.checked);
            configManager.setAutomaticTriggerEnabled(autoTriggerEnabled.checked);
            
            // Update sensor settings
            configManager.updateAIThreatSensors({
                useAccelerometer: useAccelerometer.checked,
                useHeartRate: useHeartRate.checked,
                useAudio: useAudio.checked
            });
            
            // Update threshold settings
            configManager.updateAIThreatThresholds({
                threatLevel: parseInt(threatLevelThreshold.value),
                heartRateElevation: parseInt(heartRateThreshold.value),
                audioSpike: parseInt(audioThreshold.value)
            });
            
            // Update detector settings
            sosTrigger.setPressCount(configManager.getPressCount());
            updateGestureDetectorSettings();
            updateThreatDetectorSettings();
            
            // Stop detectors if running
            if (voiceDetectionActive) {
                voiceDetector.stopListening();
                voiceDetectionActive = false;
                voiceToggleBtn.textContent = 'Start Listening';
                voiceToggleBtn.classList.remove('btn-danger');
                voiceToggleBtn.classList.add('btn-success');
                testVoiceBtn.textContent = 'Test Voice Detection';
                voiceStatus.textContent = 'Not Listening';
                voiceStatus.classList.remove('bg-danger');
                voiceStatus.classList.add('bg-secondary');
                voiceIndicator.classList.add('d-none');
                microphoneStatus.textContent = 'Voice detection stopped.';
                simulateVoiceBtn.disabled = true;
            }
            
            // Show success message
            showAlert('Configuration saved successfully!', 'success');
        } catch (error) {
            showAlert('Error: ' + error.message, 'danger');
        }
    });

    // Add contact on form submit
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        try {
            // Add new contact
            contactManager.addContact({
                name: contactNameInput.value,
                phone: contactPhoneInput.value
            });
            
            // Clear form
            contactNameInput.value = '';
            contactPhoneInput.value = '';
            
            // Update contact list
            renderContacts();
            
            // Show success message
            showAlert('Contact added successfully!', 'success');
        } catch (error) {
            showAlert('Error: ' + error.message, 'danger');
        }
    });

    //============= HELPER FUNCTIONS =============//
    
    /**
     * Updates the gesture detector settings with values from config
     */
    function updateGestureDetectorSettings() {
        const settings = configManager.getGestureSettings();
        
        gestureDetector.updateSettings({
            shakeThreshold: settings.shakeThreshold,
            requiredShakes: settings.shakeCount,
            tiltThreshold: settings.tiltThreshold,
            tiltHoldTime: settings.tiltHoldTime
        });
    }
    
    /**
     * Updates gesture settings UI based on enabled state
     */
    function updateGestureSettingsUI() {
        const enabled = configManager.areGesturesEnabled();
        
        // Enable/disable gesture settings
        const inputs = gestureSettingsPanel.querySelectorAll('input, select');
        inputs.forEach(input => {
            if (input.id !== 'gesturesEnabled') {
                input.disabled = !enabled;
            }
        });
        
        // Adjust opacity
        gestureSettingsPanel.style.opacity = enabled ? '1' : '0.5';
    }
    
    /**
     * Updates voice settings UI based on enabled state
     */
    function updateVoiceSettingsUI() {
        const enabled = configManager.isVoiceEnabled();
        
        // Enable/disable voice settings
        const inputs = voiceSettingsPanel.querySelectorAll('input, select, button');
        inputs.forEach(input => {
            if (input.id !== 'voiceEnabled') {
                input.disabled = !enabled;
            }
        });
        
        // Adjust opacity
        voiceSettingsPanel.style.opacity = enabled ? '1' : '0.5';
    }
    
    /**
     * Updates AI threat detection settings UI based on enabled state
     */
    function updateAIThreatSettingsUI() {
        const enabled = configManager.isAIThreatEnabled();
        
        // Enable/disable AI threat settings
        const inputs = aiThreatSettings.querySelectorAll('input, select, button');
        inputs.forEach(input => {
            if (input.id !== 'aiThreatEnabled') {
                input.disabled = !enabled;
            }
        });
        
        // Adjust opacity
        aiThreatSettings.style.opacity = enabled ? '1' : '0.5';
    }
    
    /**
     * Renders the voice trigger phrases list
     */
    function renderVoicePhrases() {
        phrasesList.innerHTML = '';
        
        const phrases = configManager.getVoiceTriggerPhrases();
        
        if (phrases.length === 0) {
            const emptyItem = document.createElement('li');
            emptyItem.className = 'list-group-item text-center text-muted';
            emptyItem.textContent = 'No trigger phrases added yet';
            phrasesList.appendChild(emptyItem);
            return;
        }
        
        phrases.forEach(phrase => {
            const item = document.createElement('li');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.textContent = phrase;
            
            if (phrases.length > 1) {
                const removeBtn = document.createElement('button');
                removeBtn.className = 'btn btn-sm btn-outline-danger';
                removeBtn.innerHTML = '&times;';
                removeBtn.disabled = !configManager.isVoiceEnabled();
                removeBtn.addEventListener('click', () => {
                    try {
                        configManager.removeVoiceTriggerPhrase(phrase);
                        renderVoicePhrases();
                        renderTestPhrasesSelect();
                        showAlert(`Removed phrase "${phrase}"`, 'success');
                    } catch (error) {
                        showAlert(`Error: ${error.message}`, 'danger');
                    }
                });
                
                item.appendChild(removeBtn);
            }
            
            phrasesList.appendChild(item);
        });
    }
    
    /**
     * Renders the test phrases select dropdown
     */
    function renderTestPhrasesSelect() {
        testPhraseSelect.innerHTML = '';
        
        const phrases = configManager.getVoiceTriggerPhrases();
        
        phrases.forEach(phrase => {
            const option = document.createElement('option');
            option.value = phrase;
            option.textContent = phrase;
            testPhraseSelect.appendChild(option);
        });
    }
    
    /**
     * Displays the triggered status and sends alert
     */
    async function showTriggeredStatus(triggerMethod) {
        // Show triggering status
        alertStatus.textContent = `SOS Alert triggered by ${triggerMethod}! Sending notifications...`;
        alertStatus.classList.remove('d-none', 'alert-success', 'alert-danger');
        alertStatus.classList.add('alert-warning');
        
        // Send the alert
        const result = await alertService.sendSOSAlert();
        
        if (result.success) {
            alertStatus.textContent = `SOS Alert sent successfully! (Triggered by ${triggerMethod})`;
            alertStatus.classList.remove('alert-warning', 'alert-danger');
            alertStatus.classList.add('alert-success');
            
            // Show modal with sent information
            sentMessage.textContent = configManager.getAlertMessage();
            
            // Clear and populate contacts list
            sentContacts.innerHTML = '';
            const contacts = contactManager.getContacts();
            contacts.forEach(contact => {
                const li = document.createElement('li');
                li.textContent = `${contact.name} (${contact.phone})`;
                sentContacts.appendChild(li);
            });
            
            sosModal.show();
        } else {
            alertStatus.textContent = `Error: ${result.error || 'Failed to send alert'}`;
            alertStatus.classList.remove('alert-warning', 'alert-success');
            alertStatus.classList.add('alert-danger');
        }
    }
    
    /**
     * Shows an alert message
     * @param {string} message - Alert message
     * @param {string} type - Alert type (success, danger, etc.)
     */
    function showAlert(message, type = 'info') {
        alertStatus.textContent = message;
        alertStatus.classList.remove('d-none', 'alert-success', 'alert-danger', 'alert-warning', 'alert-info');
        alertStatus.classList.add(`alert-${type}`);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            alertStatus.classList.add('d-none');
        }, 5000);
    }

    /**
     * Renders the contact list
     */
    function renderContacts() {
        contactList.innerHTML = '';
        
        const contacts = contactManager.getContacts();
        
        if (contacts.length === 0) {
            const emptyItem = document.createElement('li');
            emptyItem.className = 'list-group-item text-center text-muted';
            emptyItem.textContent = 'No emergency contacts added yet';
            contactList.appendChild(emptyItem);
            return;
        }
        
        contacts.forEach(contact => {
            const item = document.createElement('li');
            item.className = 'list-group-item contact-item';
            
            const contactInfo = document.createElement('div');
            contactInfo.innerHTML = `
                <strong>${contact.name}</strong><br>
                <small>${contact.phone}</small>
            `;
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'btn btn-sm btn-danger btn-remove';
            removeBtn.innerHTML = '<i data-feather="trash-2"></i>';
            removeBtn.addEventListener('click', () => {
                contactManager.removeContact(contact.id);
                renderContacts();
                feather.replace();
            });
            
            item.appendChild(contactInfo);
            item.appendChild(removeBtn);
            contactList.appendChild(item);
        });
        
        // Re-initialize feather icons for the new elements
        feather.replace();
    }

});
