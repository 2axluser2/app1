/**
 * SOS Trigger
 * Handles detecting and processing power button press sequences
 */
class SOSTrigger {
    constructor(configManager, alertService) {
        this.configManager = configManager;
        this.alertService = alertService;
        
        // Trigger state
        this.presses = [];
        this.timeoutId = null;
        this.isTriggered = false;
        
        // Configuration
        this.pressTimeout = 1500; // ms between presses before reset
        this.pressCount = this.configManager.getPressCount();
        
        // Event callbacks
        this.onProgress = null;
        this.onReset = null;
        this.onTrigger = null;
    }

    /**
     * Registers a button press
     */
    registerPress() {
        // Clear any existing timeout
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
        }
        
        // Don't register more presses if already triggered
        if (this.isTriggered) {
            return;
        }
        
        // Add press with timestamp
        this.presses.push({
            timestamp: Date.now()
        });
        
        // Calculate progress and notify
        const progress = (this.presses.length / this.pressCount) * 100;
        if (this.onProgress) {
            this.onProgress(progress, this.presses.length, this.pressCount);
        }
        
        // Check if we've reached the target press count
        if (this.presses.length >= this.pressCount) {
            this.triggerSOS();
            return;
        }
        
        // Set timeout to reset if there's no activity
        this.timeoutId = setTimeout(() => this.reset(), this.pressTimeout);
    }

    /**
     * Resets the press counter
     */
    reset() {
        this.presses = [];
        this.isTriggered = false;
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
        
        if (this.onReset) {
            this.onReset();
        }
    }

    /**
     * Triggers the SOS alert
     */
    async triggerSOS() {
        this.isTriggered = true;
        
        if (this.onTrigger) {
            this.onTrigger();
        }
        
        try {
            const result = await this.alertService.sendSOSAlert();
            return result;
        } catch (error) {
            console.error('Failed to send SOS alert:', error);
            return {
                success: false,
                error: error.message || 'Failed to send SOS alert',
                timestamp: new Date().toISOString()
            };
        } finally {
            // Reset after sending (or failing to send) the alert
            setTimeout(() => this.reset(), 3000);
        }
    }

    /**
     * Updates the required press count
     * @param {number} count - New press count
     */
    setPressCount(count) {
        this.pressCount = count;
        this.reset();
    }

    /**
     * Sets callback for progress updates
     * @param {Function} callback - Progress callback function
     */
    setOnProgress(callback) {
        this.onProgress = callback;
    }

    /**
     * Sets callback for trigger reset
     * @param {Function} callback - Reset callback function
     */
    setOnReset(callback) {
        this.onReset = callback;
    }

    /**
     * Sets callback for SOS trigger
     * @param {Function} callback - Trigger callback function
     */
    setOnTrigger(callback) {
        this.onTrigger = callback;
    }
}

// Create a singleton instance with the required dependencies
const sosTrigger = new SOSTrigger(configManager, alertService);
