/**
 * API Service
 * Handles communication with the backend server for persistent storage
 */
class ApiService {
    constructor() {
        // API base URL - this should point to the server we set up
        this.baseUrl = window.location.protocol + '//' + window.location.hostname + ':5001/api';
        
        // Default demo user ID (hardcoded for simplicity)
        this.currentUserId = 1;
        this.currentUsername = 'demo_user';
        
        // Initial check for server connectivity
        this.checkServerStatus();
    }
    
    /**
     * Check if the API server is reachable
     * @returns {Promise<boolean>} Whether the server is available
     */
    async checkServerStatus() {
        try {
            // First try to get the current user
            await this.getCurrentUser();
            console.log('API server is available.');
            return true;
        } catch (error) {
            console.error('API server is not available:', error);
            return false;
        }
    }
    
    /**
     * Get the current user's information
     * @returns {Promise<Object>} User information
     */
    async getCurrentUser() {
        try {
            const response = await fetch(`${this.baseUrl}/users/${this.currentUsername}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            const user = await response.json();
            this.currentUserId = user.id;
            return user;
        } catch (error) {
            console.error('Error fetching user:', error);
            throw error;
        }
    }
    
    /**
     * Get all contacts for the current user
     * @returns {Promise<Array>} List of contacts
     */
    async getContacts() {
        try {
            const response = await fetch(`${this.baseUrl}/users/${this.currentUserId}/contacts`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error fetching contacts:', error);
            // Return empty array on error for graceful degradation
            return [];
        }
    }
    
    /**
     * Add a new contact
     * @param {Object} contact - Contact object with name and phone
     * @returns {Promise<Object>} Created contact
     */
    async addContact(contact) {
        try {
            const response = await fetch(`${this.baseUrl}/users/${this.currentUserId}/contacts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(contact),
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error adding contact:', error);
            throw error;
        }
    }
    
    /**
     * Remove a contact
     * @param {string} contactId - ID of contact to remove
     * @returns {Promise<boolean>} Success status
     */
    async removeContact(contactId) {
        try {
            const response = await fetch(`${this.baseUrl}/contacts/${contactId}`, {
                method: 'DELETE',
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return true;
        } catch (error) {
            console.error('Error removing contact:', error);
            return false;
        }
    }
    
    /**
     * Get alert history
     * @returns {Promise<Array>} List of alert records
     */
    async getAlertHistory() {
        try {
            const response = await fetch(`${this.baseUrl}/users/${this.currentUserId}/alerts`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error fetching alert history:', error);
            // Return empty array on error for graceful degradation
            return [];
        }
    }
    
    /**
     * Send SOS alert
     * @param {Object} alert - Alert data including message and trigger type
     * @returns {Promise<Object>} Created alert
     */
    async sendAlert(alert) {
        try {
            const response = await fetch(`${this.baseUrl}/users/${this.currentUserId}/alerts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: alert.message,
                    triggerType: alert.triggerType,
                    locationLat: alert.locationLat,
                    locationLong: alert.locationLong,
                    contactIds: alert.contactIds,
                }),
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error sending alert:', error);
            throw error;
        }
    }
}

// Export a singleton instance
const apiService = new ApiService();