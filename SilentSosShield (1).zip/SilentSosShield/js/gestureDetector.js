/**
 * Gesture Detector
 * Detects shake and tilt gestures for SOS activation
 */
class GestureDetector {
    constructor(configManager, alertService) {
        this.configManager = configManager;
        this.alertService = alertService;
        
        // Gesture state
        this.isListening = false;
        this.isTriggered = false;
        this.accelerationData = [];
        this.orientationData = [];
        
        // Gesture settings (can be made configurable)
        this.settings = {
            // Shake detection
            shakeThreshold: 15,           // Minimum acceleration to register as shake
            shakeTimeout: 1000,           // Time window to count shakes (ms)
            requiredShakes: 3,            // Number of shakes required to trigger
            
            // Tilt detection
            tiltThreshold: 45,            // Degrees of tilt required
            tiltHoldTime: 2000,           // How long tilt must be held (ms)
            
            // Sampling
            samplingRate: 50,             // ms between acceleration readings
            dataHistoryLength: 10,        // How many readings to keep in history
            
            // Cooldown after detection
            cooldownPeriod: 3000          // ms to wait after trigger before detecting again
        };
        
        // Event callbacks
        this.onProgress = null;
        this.onReset = null;
        this.onTrigger = null;
        
        // Timers
        this.sampleTimerId = null;
        this.tiltTimerId = null;
        this.cooldownTimerId = null;
        
        // Shake detection
        this.lastShake = 0;
        this.shakeCount = 0;
        
        // Tilt detection
        this.tiltStartTime = 0;
        this.isTilted = false;
        
        // Bound methods to use as event listeners
        this.boundAccelHandler = this.handleAcceleration.bind(this);
        this.boundOrientHandler = this.handleOrientation.bind(this);
    }
    
    /**
     * Start listening for gestures
     */
    startListening() {
        if (this.isListening) return;
        
        // Check if device has required sensors
        if (window.DeviceMotionEvent && window.DeviceOrientationEvent) {
            this.isListening = true;
            
            // Modern browsers require permission for motion sensors
            if (typeof DeviceMotionEvent.requestPermission === 'function') {
                DeviceMotionEvent.requestPermission()
                    .then(response => {
                        if (response === 'granted') {
                            this.attachSensors();
                        } else {
                            console.error('Device motion permission denied');
                            this.notifyError('Motion sensors permission denied');
                        }
                    })
                    .catch(error => {
                        console.error('Error requesting device motion permission:', error);
                        this.notifyError('Could not access motion sensors');
                    });
            } else {
                // Browsers that don't require permission
                this.attachSensors();
            }
        } else {
            console.error('Device motion not supported');
            this.notifyError('Your device does not support motion detection');
        }
    }
    
    /**
     * Attach sensor event listeners
     * @private
     */
    attachSensors() {
        // Add event listeners
        window.addEventListener('devicemotion', this.boundAccelHandler);
        window.addEventListener('deviceorientation', this.boundOrientHandler);
        
        console.log('Gesture detection activated');
        
        // Start periodic sampling
        this.sampleTimerId = setInterval(() => {
            this.processAccelerationData();
        }, this.settings.samplingRate);
    }
    
    /**
     * Stop listening for gestures
     */
    stopListening() {
        if (!this.isListening) return;
        
        this.isListening = false;
        
        // Remove event listeners
        window.removeEventListener('devicemotion', this.boundAccelHandler);
        window.removeEventListener('deviceorientation', this.boundOrientHandler);
        
        // Clear timers
        if (this.sampleTimerId) {
            clearInterval(this.sampleTimerId);
            this.sampleTimerId = null;
        }
        
        if (this.tiltTimerId) {
            clearTimeout(this.tiltTimerId);
            this.tiltTimerId = null;
        }
        
        // Reset data
        this.accelerationData = [];
        this.orientationData = [];
        
        console.log('Gesture detection deactivated');
    }
    
    /**
     * Handle device acceleration data
     * @param {DeviceMotionEvent} event - Motion event
     * @private
     */
    handleAcceleration(event) {
        // Skip if not listening or during cooldown
        if (!this.isListening || this.isTriggered) return;
        
        const accel = event.accelerationIncludingGravity;
        if (!accel) return;
        
        // Add data to history
        this.accelerationData.push({
            x: accel.x || 0,
            y: accel.y || 0,
            z: accel.z || 0,
            timestamp: Date.now()
        });
        
        // Keep history at desired length
        if (this.accelerationData.length > this.settings.dataHistoryLength) {
            this.accelerationData.shift();
        }
    }
    
    /**
     * Handle device orientation data
     * @param {DeviceOrientationEvent} event - Orientation event
     * @private
     */
    handleOrientation(event) {
        // Skip if not listening or during cooldown
        if (!this.isListening || this.isTriggered) return;
        
        const orientation = {
            alpha: event.alpha || 0,  // Z-axis rotation [0, 360)
            beta: event.beta || 0,    // X-axis rotation [-180, 180)
            gamma: event.gamma || 0,  // Y-axis rotation [-90, 90)
            timestamp: Date.now()
        };
        
        // Add data to history
        this.orientationData.push(orientation);
        
        // Keep history at desired length
        if (this.orientationData.length > this.settings.dataHistoryLength) {
            this.orientationData.shift();
        }
        
        // Check for tilt gesture
        this.processTiltData(orientation);
    }
    
    /**
     * Process acceleration data to detect shakes
     * @private
     */
    processAccelerationData() {
        if (!this.isListening || this.isTriggered || this.accelerationData.length < 2) return;
        
        const now = Date.now();
        const sample = this.accelerationData[this.accelerationData.length - 1];
        const prevSample = this.accelerationData[this.accelerationData.length - 2];
        
        // Calculate acceleration magnitude change
        const deltaX = Math.abs(sample.x - prevSample.x);
        const deltaY = Math.abs(sample.y - prevSample.y);
        const deltaZ = Math.abs(sample.z - prevSample.z);
        
        const acceleration = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
        
        // Check if this acceleration passes the threshold for a shake
        if (acceleration >= this.settings.shakeThreshold) {
            // If this is the first shake or it's been too long since the last one, reset counter
            if (now - this.lastShake > this.settings.shakeTimeout) {
                this.shakeCount = 1;
            } else {
                this.shakeCount++;
            }
            
            this.lastShake = now;
            
            // Calculate progress and notify
            const progress = (this.shakeCount / this.settings.requiredShakes) * 100;
            if (this.onProgress) {
                this.onProgress(progress, this.shakeCount, this.settings.requiredShakes);
            }
            
            // Check if we've reached the required number of shakes
            if (this.shakeCount >= this.settings.requiredShakes) {
                this.triggerSOS("shake");
            }
        }
    }
    
    /**
     * Process orientation data to detect tilts
     * @param {Object} orientation - Current orientation data
     * @private
     */
    processTiltData(orientation) {
        if (!this.isListening || this.isTriggered) return;
        
        const now = Date.now();
        
        // Check if device is tilted past threshold (check both beta and gamma for any severe tilt)
        const isTiltedNow = Math.abs(orientation.beta) > this.settings.tiltThreshold || 
                            Math.abs(orientation.gamma) > this.settings.tiltThreshold;
        
        // State transition detection
        if (isTiltedNow && !this.isTilted) {
            // Just started tilting
            this.isTilted = true;
            this.tiltStartTime = now;
            
            // Set timer to check if tilt is held long enough
            this.tiltTimerId = setTimeout(() => {
                if (this.isTilted) {
                    this.triggerSOS("tilt");
                }
            }, this.settings.tiltHoldTime);
            
            // Start progress notification
            if (this.onProgress) {
                this.onProgress(1, 1, 100); // Start progress
            }
            
        } else if (!isTiltedNow && this.isTilted) {
            // Just stopped tilting
            this.isTilted = false;
            
            // Clear tilt timer
            if (this.tiltTimerId) {
                clearTimeout(this.tiltTimerId);
                this.tiltTimerId = null;
            }
            
            // Reset progress
            if (this.onProgress) {
                this.onProgress(0, 0, 100); // Reset progress
            }
        } else if (this.isTilted) {
            // Continuing to tilt, update progress
            const elapsed = now - this.tiltStartTime;
            const progress = Math.min(100, (elapsed / this.settings.tiltHoldTime) * 100);
            
            if (this.onProgress) {
                this.onProgress(progress, elapsed, this.settings.tiltHoldTime);
            }
        }
    }
    
    /**
     * Triggers the SOS alert
     * @param {string} triggerType - What triggered the alert ("shake" or "tilt")
     * @private
     */
    async triggerSOS(triggerType) {
        if (this.isTriggered) return;
        
        this.isTriggered = true;
        
        // Notify triggering
        if (this.onTrigger) {
            this.onTrigger(triggerType);
        }
        
        try {
            const result = await this.alertService.sendSOSAlert();
            
            // Set cooldown period
            this.cooldownTimerId = setTimeout(() => {
                this.reset();
            }, this.settings.cooldownPeriod);
            
            return result;
        } catch (error) {
            console.error(`Failed to send SOS alert (${triggerType}):`, error);
            this.reset();
            return {
                success: false,
                error: error.message || 'Failed to send SOS alert',
                timestamp: new Date().toISOString(),
                triggerType: triggerType
            };
        }
    }
    
    /**
     * Reset detector state
     */
    reset() {
        // Clear all timers
        if (this.tiltTimerId) {
            clearTimeout(this.tiltTimerId);
            this.tiltTimerId = null;
        }
        
        if (this.cooldownTimerId) {
            clearTimeout(this.cooldownTimerId);
            this.cooldownTimerId = null;
        }
        
        // Reset state
        this.isTriggered = false;
        this.shakeCount = 0;
        this.lastShake = 0;
        this.isTilted = false;
        this.tiltStartTime = 0;
        
        // Notify reset
        if (this.onReset) {
            this.onReset();
        }
    }
    
    /**
     * Notify of an error
     * @param {string} message - Error message
     * @private
     */
    notifyError(message) {
        console.error('Gesture Detector Error:', message);
        
        // Create a custom event for the app to listen for
        const event = new CustomEvent('gesturedetectorerror', {
            detail: { message }
        });
        document.dispatchEvent(event);
    }
    
    /**
     * Update detector settings
     * @param {Object} newSettings - New settings object
     */
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
    }
    
    /**
     * Sets callback for progress updates
     * @param {Function} callback - Progress callback function
     */
    setOnProgress(callback) {
        this.onProgress = callback;
    }
    
    /**
     * Sets callback for detector reset
     * @param {Function} callback - Reset callback function
     */
    setOnReset(callback) {
        this.onReset = callback;
    }
    
    /**
     * Sets callback for SOS trigger
     * @param {Function} callback - Trigger callback function
     */
    setOnTrigger(callback) {
        this.onTrigger = callback;
    }
}

// Create a singleton instance with the required dependencies
const gestureDetector = new GestureDetector(configManager, alertService);