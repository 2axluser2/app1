/**
 * Predictive Learning Module
 * Learns from historical user behavior and environmental data
 * to detect anomalies and improve threat detection accuracy
 */
class PredictiveLearning {
    constructor(configManager, threatDetector) {
        this.configManager = configManager;
        this.threatDetector = threatDetector;
        this.settings = configManager.getPredictiveLearningSettings();
        
        // Storage for behavioral patterns
        this.patterns = {
            timeOfDay: {}, // Time patterns (when user is typically active)
            locations: {}, // Common locations
            routes: [],    // Common travel routes
            activities: {} // Activity patterns (walking, running, stationary periods)
        };
        
        // Storage for behavioral history
        this.history = {
            movements: [],  // Historical movement data
            heartRates: [], // Historical heart rate data
            audioLevels: [] // Historical audio level data
        };
        
        // Load saved patterns from localStorage if available
        this.loadPatterns();
        
        // Pattern recognition confidence (increases as more data is collected)
        this.confidence = 0.1; // Starts low, increases with data collection
        
        this.anomalyThreshold = this.settings.anomalyThreshold;
        this.learningRate = this.settings.learningRate;
        this.maxHistoryLength = this.settings.maxHistoryLength;
        
        // Scheduled learning tasks
        this.captureInterval = null;
        this.analysisInterval = null;
    }
    
    /**
     * Start learning process
     */
    start() {
        if (this.captureInterval || this.analysisInterval) {
            this.stop(); // Stop any existing intervals
        }
        
        // Capture data at regular intervals
        this.captureInterval = setInterval(() => {
            this.captureCurrentState();
        }, this.settings.captureInterval);
        
        // Analyze patterns less frequently
        this.analysisInterval = setInterval(() => {
            this.analyzePatterns();
        }, this.settings.analysisInterval);
        
        console.log('Predictive learning started');
    }
    
    /**
     * Stop learning process
     */
    stop() {
        if (this.captureInterval) {
            clearInterval(this.captureInterval);
            this.captureInterval = null;
        }
        
        if (this.analysisInterval) {
            clearInterval(this.analysisInterval);
            this.analysisInterval = null;
        }
        
        console.log('Predictive learning stopped');
    }
    
    /**
     * Capture current user state and environmental data
     */
    captureCurrentState() {
        if (!this.threatDetector.active) {
            return; // Only capture when threat detector is active
        }
        
        const now = new Date();
        const timeOfDay = now.getHours() * 60 + now.getMinutes(); // Minutes since midnight
        const dayOfWeek = now.getDay(); // 0-6 (Sunday-Saturday)
        
        // Capture movement type
        const movementData = {
            timestamp: now.getTime(),
            timeOfDay: timeOfDay,
            dayOfWeek: dayOfWeek,
            type: this.threatDetector.movementType,
            // In a real app, this would include GPS location
            location: this.simulateLocation()
        };
        
        // Capture heart rate
        const heartRateData = {
            timestamp: now.getTime(),
            timeOfDay: timeOfDay,
            dayOfWeek: dayOfWeek,
            rate: this.threatDetector.heartRate
        };
        
        // Capture audio level
        const audioData = {
            timestamp: now.getTime(),
            timeOfDay: timeOfDay,
            dayOfWeek: dayOfWeek,
            level: this.threatDetector.audioLevel
        };
        
        // Add to history with length limit
        this.addToHistory('movements', movementData);
        this.addToHistory('heartRates', heartRateData);
        this.addToHistory('audioLevels', audioData);
        
        // Update time-of-day activity patterns
        this.updateTimeOfDayPattern(timeOfDay, dayOfWeek, movementData.type);
        
        // Save patterns periodically
        if (Math.random() < 0.2) { // 20% chance to save on each capture to reduce writes
            this.savePatterns();
        }
    }
    
    /**
     * Adds data to history array with maximum length constraint
     * @param {string} historyType - Type of history data
     * @param {object} data - Data to add
     */
    addToHistory(historyType, data) {
        this.history[historyType].push(data);
        
        // Keep history within maximum length
        if (this.history[historyType].length > this.maxHistoryLength) {
            this.history[historyType].shift(); // Remove oldest entry
        }
    }
    
    /**
     * Update time-of-day activity patterns
     * @param {number} timeOfDay - Minutes since midnight
     * @param {number} dayOfWeek - Day of week (0-6)
     * @param {string} activityType - Type of activity
     */
    updateTimeOfDayPattern(timeOfDay, dayOfWeek, activityType) {
        // Group time into 30-minute buckets
        const timeBlock = Math.floor(timeOfDay / 30) * 30;
        
        // Create keys for storage
        const timeKey = `${timeBlock}`;
        const dayTimeKey = `${dayOfWeek}_${timeBlock}`;
        
        // Initialize time pattern objects if they don't exist
        if (!this.patterns.timeOfDay[timeKey]) {
            this.patterns.timeOfDay[timeKey] = {
                stationary: 0,
                walking: 0,
                running: 0,
                erratic: 0,
                total: 0
            };
        }
        
        if (!this.patterns.timeOfDay[dayTimeKey]) {
            this.patterns.timeOfDay[dayTimeKey] = {
                stationary: 0,
                walking: 0,
                running: 0,
                erratic: 0,
                total: 0
            };
        }
        
        // Update general time pattern (across all days)
        this.patterns.timeOfDay[timeKey][activityType]++;
        this.patterns.timeOfDay[timeKey].total++;
        
        // Update day-specific time pattern
        this.patterns.timeOfDay[dayTimeKey][activityType]++;
        this.patterns.timeOfDay[dayTimeKey].total++;
    }
    
    /**
     * Analyze patterns to identify typical behavior and anomalies
     */
    analyzePatterns() {
        if (this.history.movements.length < 10) {
            // Not enough data for meaningful analysis
            return;
        }
        
        // Increase confidence as we collect more data (caps at 0.9)
        this.confidence = Math.min(0.9, 0.1 + (this.history.movements.length / this.maxHistoryLength) * 0.8);
        
        // Analyze recent behavior
        const now = new Date();
        const timeOfDay = now.getHours() * 60 + now.getMinutes(); // Minutes since midnight
        const dayOfWeek = now.getDay();
        
        // Analyze current behavior against patterns
        const anomalyScore = this.calculateAnomalyScore(timeOfDay, dayOfWeek);
        
        // If anomaly is detected, adjust threat detector sensitivity
        if (anomalyScore > this.anomalyThreshold) {
            this.adjustThreatSensitivity(anomalyScore);
            console.log('Behavioral anomaly detected', {
                anomalyScore,
                timeOfDay,
                dayOfWeek,
                currentMovement: this.threatDetector.movementType,
                confidence: this.confidence
            });
        }
    }
    
    /**
     * Calculate how unusual current behavior is based on historical patterns
     * @param {number} timeOfDay - Current time (minutes since midnight)
     * @param {number} dayOfWeek - Current day of week (0-6)
     * @returns {number} Anomaly score (0-100), higher means more anomalous
     */
    calculateAnomalyScore(timeOfDay, dayOfWeek) {
        // Time block (30-minute intervals)
        const timeBlock = Math.floor(timeOfDay / 30) * 30;
        
        // Get time patterns
        const timeKey = `${timeBlock}`;
        const dayTimeKey = `${dayOfWeek}_${timeBlock}`;
        const timePattern = this.patterns.timeOfDay[timeKey];
        const dayTimePattern = this.patterns.timeOfDay[dayTimeKey];
        
        // If we don't have data for this time, that's somewhat anomalous
        if (!timePattern || timePattern.total < 5) {
            return 50; // Moderate anomaly score for unknown time periods
        }
        
        // Current activity
        const currentActivity = this.threatDetector.movementType;
        
        // Calculate how often this activity occurs during this time block
        const generalFrequency = timePattern[currentActivity] / timePattern.total;
        
        // Day-specific frequency (if we have enough data)
        const daySpecificFrequency = dayTimePattern && dayTimePattern.total > 3 ?
            dayTimePattern[currentActivity] / dayTimePattern.total : generalFrequency;
        
        // Combine frequencies (more weight to day-specific if available)
        const expectedFrequency = dayTimePattern && dayTimePattern.total > 3 ?
            (daySpecificFrequency * 0.7) + (generalFrequency * 0.3) : generalFrequency;
        
        // Activities that rarely happen during this time are more anomalous
        const baseAnomalyScore = 100 - (expectedFrequency * 100);
        
        // Special case: running is inherently more anomalous than walking or stationary
        const activityRiskFactor = currentActivity === 'running' ? 1.5 :
                               currentActivity === 'erratic' ? 2.0 : 1.0;
        
        // Calculate final anomaly score (0-100 scale)
        let finalScore = baseAnomalyScore * activityRiskFactor;
        
        // Adjust based on confidence in our data
        finalScore = finalScore * this.confidence;
        
        // Also consider heart rate anomaly
        const heartRateAnomalyScore = this.calculateHeartRateAnomaly(timeOfDay, dayOfWeek);
        
        // Also consider audio level anomaly
        const audioAnomalyScore = this.calculateAudioAnomaly(timeOfDay, dayOfWeek);
        
        // Combine all anomaly factors
        const combinedScore = (finalScore * 0.6) + (heartRateAnomalyScore * 0.25) + (audioAnomalyScore * 0.15);
        
        return Math.min(100, combinedScore);
    }
    
    /**
     * Calculate heart rate anomaly score
     * @param {number} timeOfDay - Current time (minutes since midnight)
     * @param {number} dayOfWeek - Current day of week (0-6)
     * @returns {number} Anomaly score (0-100)
     */
    calculateHeartRateAnomaly(timeOfDay, dayOfWeek) {
        // Need enough data to calculate meaningful average
        if (this.history.heartRates.length < 10) {
            return 0;
        }
        
        // Get current heart rate
        const currentRate = this.threatDetector.heartRate;
        
        // Calculate average heart rate for this time of day
        const timeWindow = 60; // Look at samples within 60 minutes of current time
        const relevantSamples = this.history.heartRates.filter(sample => {
            const sampleTime = new Date(sample.timestamp).getHours() * 60 + 
                              new Date(sample.timestamp).getMinutes();
            
            // Is this sample within our time window and not from today?
            return Math.abs(sampleTime - timeOfDay) <= timeWindow && 
                   new Date(sample.timestamp).getDay() !== dayOfWeek;
        });
        
        if (relevantSamples.length < 5) {
            return 0; // Not enough data
        }
        
        // Calculate average and standard deviation
        const rates = relevantSamples.map(sample => sample.rate);
        const avgRate = rates.reduce((sum, rate) => sum + rate, 0) / rates.length;
        const variance = rates.reduce((sum, rate) => sum + Math.pow(rate - avgRate, 2), 0) / rates.length;
        const stdDev = Math.sqrt(variance);
        
        // Calculate z-score (how many standard deviations from mean)
        const zScore = Math.abs((currentRate - avgRate) / stdDev);
        
        // Convert to anomaly score (0-100)
        // A z-score of 2 (95% confidence) = 50, z-score of 3 (99.7% confidence) = 75
        return Math.min(100, zScore * 25);
    }
    
    /**
     * Calculate audio level anomaly score
     * @param {number} timeOfDay - Current time (minutes since midnight)
     * @param {number} dayOfWeek - Current day of week (0-6)
     * @returns {number} Anomaly score (0-100)
     */
    calculateAudioAnomaly(timeOfDay, dayOfWeek) {
        // Need enough data to calculate meaningful average
        if (this.history.audioLevels.length < 10) {
            return 0;
        }
        
        // Get current audio level
        const currentLevel = this.threatDetector.audioLevel;
        
        // Calculate average audio level for this time of day
        const timeWindow = 60; // Look at samples within 60 minutes of current time
        const relevantSamples = this.history.audioLevels.filter(sample => {
            const sampleTime = new Date(sample.timestamp).getHours() * 60 + 
                              new Date(sample.timestamp).getMinutes();
            
            // Is this sample within our time window?
            return Math.abs(sampleTime - timeOfDay) <= timeWindow;
        });
        
        if (relevantSamples.length < 5) {
            return 0; // Not enough data
        }
        
        // Calculate average and standard deviation
        const levels = relevantSamples.map(sample => sample.level);
        const avgLevel = levels.reduce((sum, level) => sum + level, 0) / levels.length;
        
        // Audio tends to spike, so we're mainly concerned with significant increases
        if (currentLevel <= avgLevel * 1.5) {
            return 0; // Not anomalous
        }
        
        // Calculate how many times higher than normal
        const ratio = currentLevel / avgLevel;
        
        // Convert to anomaly score (0-100)
        // 2x normal = 25, 3x normal = 50, 4x or more = 75+
        return Math.min(100, (ratio - 1) * 25);
    }
    
    /**
     * Adjust threat detector sensitivity based on anomaly score
     * @param {number} anomalyScore - How anomalous current behavior is (0-100)
     */
    adjustThreatSensitivity(anomalyScore) {
        // Only make adjustments if we have enough confidence
        if (this.confidence < 0.3) {
            return;
        }
        
        // Calculate sensitivity adjustment
        // Higher anomaly score = lower threshold (more sensitive)
        const curSettings = this.threatDetector.settings;
        
        // Temporary thresholds for current analysis only
        const adjustedSettings = {
            thresholds: { ...curSettings.thresholds }
        };
        
        if (anomalyScore > 75) {
            // High anomaly - make significantly more sensitive
            adjustedSettings.thresholds.threatLevel = Math.max(50, curSettings.thresholds.threatLevel - 20);
            adjustedSettings.thresholds.heartRateElevation = Math.max(15, curSettings.thresholds.heartRateElevation - 10);
            adjustedSettings.thresholds.audioSpike = Math.max(2, curSettings.thresholds.audioSpike - 1);
        } else if (anomalyScore > 50) {
            // Moderate anomaly - make moderately more sensitive
            adjustedSettings.thresholds.threatLevel = Math.max(60, curSettings.thresholds.threatLevel - 10);
            adjustedSettings.thresholds.heartRateElevation = Math.max(20, curSettings.thresholds.heartRateElevation - 5);
            adjustedSettings.thresholds.audioSpike = Math.max(2, Math.floor(curSettings.thresholds.audioSpike * 0.8));
        } else if (anomalyScore > 25) {
            // Mild anomaly - make slightly more sensitive
            adjustedSettings.thresholds.threatLevel = Math.max(70, curSettings.thresholds.threatLevel - 5);
            adjustedSettings.thresholds.heartRateElevation = Math.max(25, curSettings.thresholds.heartRateElevation - 2);
        }
        
        // Apply the temporary settings
        this.threatDetector.updateSettings(adjustedSettings);
        
        // Log the adjustment
        console.log('Adjusted threat sensitivity based on behavioral anomaly', {
            anomalyScore,
            originalThreshold: curSettings.thresholds.threatLevel,
            newThreshold: adjustedSettings.thresholds.threatLevel
        });
        
        // Schedule reverting back to original settings
        setTimeout(() => {
            this.threatDetector.updateSettings(curSettings);
            console.log('Reverted threat sensitivity to normal levels');
        }, 5 * 60 * 1000); // Revert after 5 minutes
    }
    
    /**
     * Simulate location data (for demo purposes)
     * @returns {Object} Simulated location
     * @private
     */
    simulateLocation() {
        // In a real app, this would use actual GPS coordinates
        // For demo, we'll simulate 5 locations the user commonly visits
        const commonLocations = [
            { name: 'home', lat: 37.7749, lng: -122.4194 },
            { name: 'work', lat: 37.7833, lng: -122.4167 },
            { name: 'gym', lat: 37.7850, lng: -122.4100 },
            { name: 'friend', lat: 37.7700, lng: -122.4150 },
            { name: 'store', lat: 37.7820, lng: -122.4200 }
        ];
        
        // Time-based location simulation (different locations more likely at different times)
        const hour = new Date().getHours();
        
        // Probabilities change throughout the day
        let locationProbs;
        
        if (hour >= 22 || hour < 7) {
            // Night - mostly at home
            locationProbs = [0.95, 0.01, 0.01, 0.02, 0.01];
        } else if (hour >= 9 && hour < 17) {
            // Work hours
            locationProbs = [0.05, 0.85, 0.05, 0.03, 0.02];
        } else if (hour >= 17 && hour < 19) {
            // Evening - more likely at gym
            locationProbs = [0.30, 0.10, 0.40, 0.15, 0.05];
        } else if (hour >= 19 && hour < 22) {
            // Evening - more likely at home or friend's
            locationProbs = [0.60, 0.05, 0.05, 0.25, 0.05];
        } else {
            // Other times - varied
            locationProbs = [0.50, 0.20, 0.10, 0.10, 0.10];
        }
        
        // Pick location based on probabilities
        const rand = Math.random();
        let cumProb = 0;
        let selectedIndex = 0;
        
        for (let i = 0; i < locationProbs.length; i++) {
            cumProb += locationProbs[i];
            if (rand <= cumProb) {
                selectedIndex = i;
                break;
            }
        }
        
        // Add some random noise to the exact location
        const location = commonLocations[selectedIndex];
        const latNoise = (Math.random() - 0.5) * 0.002; // ~100-200m noise
        const lngNoise = (Math.random() - 0.5) * 0.002;
        
        return {
            name: location.name,
            lat: location.lat + latNoise,
            lng: location.lng + lngNoise
        };
    }
    
    /**
     * Save patterns to localStorage
     */
    savePatterns() {
        try {
            localStorage.setItem('predictivePatterns', JSON.stringify(this.patterns));
            localStorage.setItem('predictiveHistory', JSON.stringify({
                movements: this.history.movements.slice(-50),   // Only store the most recent items
                heartRates: this.history.heartRates.slice(-50),
                audioLevels: this.history.audioLevels.slice(-50)
            }));
            localStorage.setItem('predictiveConfidence', this.confidence.toString());
        } catch (error) {
            console.error('Failed to save predictive patterns:', error);
        }
    }
    
    /**
     * Load patterns from localStorage
     */
    loadPatterns() {
        try {
            const savedPatterns = localStorage.getItem('predictivePatterns');
            if (savedPatterns) {
                this.patterns = JSON.parse(savedPatterns);
            }
            
            const savedHistory = localStorage.getItem('predictiveHistory');
            if (savedHistory) {
                const parsedHistory = JSON.parse(savedHistory);
                if (parsedHistory.movements) this.history.movements = parsedHistory.movements;
                if (parsedHistory.heartRates) this.history.heartRates = parsedHistory.heartRates;
                if (parsedHistory.audioLevels) this.history.audioLevels = parsedHistory.audioLevels;
            }
            
            const savedConfidence = localStorage.getItem('predictiveConfidence');
            if (savedConfidence) {
                this.confidence = parseFloat(savedConfidence);
            }
            
            console.log('Loaded predictive patterns and history', {
                patternsLoaded: Object.keys(this.patterns.timeOfDay).length > 0,
                historySize: {
                    movements: this.history.movements.length,
                    heartRates: this.history.heartRates.length,
                    audioLevels: this.history.audioLevels.length
                },
                confidence: this.confidence
            });
        } catch (error) {
            console.error('Failed to load predictive patterns:', error);
            // Reset patterns to empty state
            this.patterns = {
                timeOfDay: {},
                locations: {},
                routes: [],
                activities: {}
            };
            this.history = {
                movements: [],
                heartRates: [],
                audioLevels: []
            };
            this.confidence = 0.1;
        }
    }
    
    /**
     * Get the current anomaly detection results
     * @returns {Object} Anomaly detection results
     */
    getAnomalyStatus() {
        const now = new Date();
        const timeOfDay = now.getHours() * 60 + now.getMinutes();
        const dayOfWeek = now.getDay();
        
        const anomalyScore = this.calculateAnomalyScore(timeOfDay, dayOfWeek);
        const movementAnomaly = this.history.movements.length >= 10 ? 
            this.isCurrentMovementAnomalous(timeOfDay, dayOfWeek) : false;
        const heartRateAnomaly = this.history.heartRates.length >= 10 ?
            this.calculateHeartRateAnomaly(timeOfDay, dayOfWeek) > 50 : false;
        const audioAnomaly = this.history.audioLevels.length >= 10 ?
            this.calculateAudioAnomaly(timeOfDay, dayOfWeek) > 50 : false;
        
        return {
            anomalyScore,
            dataConfidence: this.confidence,
            components: {
                movementAnomaly,
                heartRateAnomaly,
                audioAnomaly
            },
            learnedPatterns: {
                totalTimeBlocks: Object.keys(this.patterns.timeOfDay).length,
                totalDataPoints: this.history.movements.length + this.history.heartRates.length + this.history.audioLevels.length
            }
        };
    }
    
    /**
     * Check if current movement is anomalous for this time of day
     * @param {number} timeOfDay - Current time (minutes since midnight)
     * @param {number} dayOfWeek - Current day of week (0-6)
     * @returns {boolean} True if current movement is anomalous
     */
    isCurrentMovementAnomalous(timeOfDay, dayOfWeek) {
        const timeBlock = Math.floor(timeOfDay / 30) * 30;
        const timeKey = `${timeBlock}`;
        const timePattern = this.patterns.timeOfDay[timeKey];
        
        if (!timePattern || timePattern.total < 5) {
            return false; // Not enough data
        }
        
        const currentActivity = this.threatDetector.movementType;
        const frequency = timePattern[currentActivity] / timePattern.total;
        
        // If this activity happens less than 15% of the time during this period, it's anomalous
        return frequency < 0.15;
    }
    
    /**
     * Export learning data for visualization or analysis
     * @returns {Object} Learning data
     */
    exportLearningData() {
        return {
            patterns: this.patterns,
            history: {
                movementCount: this.history.movements.length,
                heartRateCount: this.history.heartRates.length,
                audioLevelCount: this.history.audioLevels.length,
                // Include just the last 10 data points of each type
                recentMovements: this.history.movements.slice(-10),
                recentHeartRates: this.history.heartRates.slice(-10),
                recentAudioLevels: this.history.audioLevels.slice(-10)
            },
            confidence: this.confidence,
            anomalyThreshold: this.anomalyThreshold,
            learningRate: this.learningRate
        };
    }
}

/**
 * Create a predictive learning module
 * @param {ConfigManager} configManager - Configuration manager
 * @param {ThreatDetector} threatDetector - Threat detector instance
 * @returns {PredictiveLearning} Predictive learning module
 */
function createPredictiveLearning(configManager, threatDetector) {
    return new PredictiveLearning(configManager, threatDetector);
}