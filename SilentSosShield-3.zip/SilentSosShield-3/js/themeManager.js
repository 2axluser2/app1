/**
 * Theme Manager
 * Handles switching between light and dark themes
 */
class ThemeManager {
    constructor() {
        this.darkTheme = false;
        this.init();
    }

    /**
     * Initialize the theme manager
     */
    init() {
        // Check if user has already set a preference
        const savedTheme = localStorage.getItem('sosAppTheme');
        if (savedTheme) {
            this.darkTheme = savedTheme === 'dark';
            this.applyTheme();
        }

        // Create theme toggle element
        this.createThemeToggle();
    }

    /**
     * Create the theme toggle UI element
     */
    createThemeToggle() {
        // Create toggle container
        const toggle = document.createElement('div');
        toggle.className = 'theme-toggle';
        if (this.darkTheme) {
            toggle.classList.add('dark');
        }
        
        // Create toggle slider
        const slider = document.createElement('div');
        slider.className = 'theme-toggle-slider';
        
        // Add icon to slider
        const icon = document.createElement('span');
        icon.className = 'theme-toggle-icon';
        icon.innerHTML = this.darkTheme ? '🌙' : '☀️';
        slider.appendChild(icon);
        
        // Add slider to toggle
        toggle.appendChild(slider);
        
        // Add click event
        toggle.addEventListener('click', () => this.toggleTheme());
        
        // Add to body
        document.body.appendChild(toggle);
    }

    /**
     * Toggle between light and dark themes
     */
    toggleTheme() {
        this.darkTheme = !this.darkTheme;
        this.applyTheme();
        
        // Update toggle UI
        const toggle = document.querySelector('.theme-toggle');
        const icon = document.querySelector('.theme-toggle-icon');
        
        if (this.darkTheme) {
            toggle.classList.add('dark');
            icon.innerHTML = '🌙';
        } else {
            toggle.classList.remove('dark');
            icon.innerHTML = '☀️';
        }
        
        // Save preference
        localStorage.setItem('sosAppTheme', this.darkTheme ? 'dark' : 'light');
    }

    /**
     * Apply the current theme to the document
     */
    applyTheme() {
        if (this.darkTheme) {
            // Apply dark theme
            document.body.classList.add('dark-theme');
            
            // Add dark theme stylesheet if not already added
            if (!document.getElementById('dark-theme-css')) {
                const darkThemeLink = document.createElement('link');
                darkThemeLink.id = 'dark-theme-css';
                darkThemeLink.rel = 'stylesheet';
                darkThemeLink.href = 'css/dark-theme.css';
                document.head.appendChild(darkThemeLink);
            }
        } else {
            // Remove dark theme
            document.body.classList.remove('dark-theme');
            
            // Remove dark theme stylesheet
            const darkThemeLink = document.getElementById('dark-theme-css');
            if (darkThemeLink) {
                darkThemeLink.remove();
            }
        }
    }
}

// Initialize the theme manager when the DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.themeManager = new ThemeManager();
});