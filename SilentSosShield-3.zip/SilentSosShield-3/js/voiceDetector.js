/**
 * Voice Detector
 * Detects voice commands for SOS activation
 * Uses the Web Speech API for speech recognition
 */
class VoiceDetector {
    constructor(configManager, alertService) {
        this.configManager = configManager;
        this.alertService = alertService;
        
        // Recognition object
        this.recognition = null;
        
        // State tracking
        this.isListening = false;
        this.lastTriggerTime = 0;
        this.cooldownPeriod = 10000; // 10 seconds cooldown between triggers
        
        // Callbacks
        this.onProgressCallback = null;
        this.onResetCallback = null;
        this.onTriggerCallback = null;
        this.onErrorCallback = null;
        
        // Initialize if supported
        this.initSpeechRecognition();
    }
    
    /**
     * Initialize the Speech Recognition API
     * @private
     */
    initSpeechRecognition() {
        try {
            // Check for browser support
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            
            if (!SpeechRecognition) {
                this.notifyError("Speech recognition not supported in this browser");
                return;
            }
            
            this.recognition = new SpeechRecognition();
            
            // Configure the recognition
            this.recognition.continuous = true;
            this.recognition.interimResults = false;
            this.recognition.lang = 'en-US'; // Default language
            
            // Set up event handlers
            this.recognition.onresult = this.handleSpeechResult.bind(this);
            this.recognition.onerror = this.handleSpeechError.bind(this);
            this.recognition.onend = this.handleSpeechEnd.bind(this);
            
            console.log("Speech recognition initialized");
        } catch (error) {
            this.notifyError(`Error initializing speech recognition: ${error.message}`);
        }
    }
    
    /**
     * Start listening for voice commands
     */
    startListening() {
        if (!this.recognition) {
            this.notifyError("Speech recognition not available");
            return;
        }
        
        if (this.isListening) return;
        
        try {
            this.recognition.start();
            this.isListening = true;
            console.log("Voice detection started");
        } catch (error) {
            this.notifyError(`Error starting speech recognition: ${error.message}`);
        }
    }
    
    /**
     * Stop listening for voice commands
     */
    stopListening() {
        if (!this.recognition || !this.isListening) return;
        
        try {
            this.recognition.stop();
            this.isListening = false;
            console.log("Voice detection stopped");
        } catch (error) {
            console.error("Error stopping speech recognition:", error);
        }
    }
    
    /**
     * Process speech recognition results
     * @param {SpeechRecognitionEvent} event - The speech recognition event
     * @private
     */
    handleSpeechResult(event) {
        const lastResult = event.results[event.results.length - 1];
        const transcript = lastResult[0].transcript.trim().toLowerCase();
        
        console.log("Speech detected:", transcript);
        
        // Get configured phrases
        const triggerPhrases = this.configManager.getVoiceTriggerPhrases();
        const confidenceThreshold = this.configManager.getVoiceConfidenceThreshold();
        
        // Check if transcript matches any trigger phrase
        const matchedPhrase = triggerPhrases.find(phrase => 
            transcript.includes(phrase.toLowerCase())
        );
        
        if (matchedPhrase && lastResult[0].confidence >= confidenceThreshold) {
            // Check cooldown period to prevent accidental multiple triggers
            const now = Date.now();
            if (now - this.lastTriggerTime >= this.cooldownPeriod) {
                this.lastTriggerTime = now;
                this.triggerSOS(matchedPhrase);
            } else {
                console.log("Voice trigger in cooldown period");
            }
        }
    }
    
    /**
     * Handle speech recognition errors
     * @param {SpeechRecognitionError} event - The error event
     * @private
     */
    handleSpeechError(event) {
        let errorMessage = "";
        
        switch (event.error) {
            case 'no-speech':
                errorMessage = "No speech detected";
                break;
            case 'aborted':
                errorMessage = "Speech recognition aborted";
                break;
            case 'audio-capture':
                errorMessage = "Could not capture audio";
                break;
            case 'not-allowed':
                errorMessage = "Microphone access not allowed";
                break;
            case 'service-not-allowed':
                errorMessage = "Speech recognition service not allowed";
                break;
            case 'bad-grammar':
                errorMessage = "Grammar error in speech recognition";
                break;
            case 'language-not-supported':
                errorMessage = "Language not supported";
                break;
            default:
                errorMessage = `Speech recognition error: ${event.error}`;
        }
        
        console.error(errorMessage);
        
        if (this.onErrorCallback) {
            this.onErrorCallback(errorMessage);
        }
        
        // Auto-restart if not a permission error
        if (event.error !== 'not-allowed' && event.error !== 'service-not-allowed' && this.isListening) {
            setTimeout(() => {
                if (this.isListening) {
                    try {
                        this.recognition.start();
                    } catch (e) {
                        console.error("Error restarting speech recognition:", e);
                    }
                }
            }, 1000);
        } else {
            this.isListening = false;
        }
    }
    
    /**
     * Handle speech recognition end event
     * @private
     */
    handleSpeechEnd() {
        // Auto-restart if still in listening mode
        if (this.isListening) {
            try {
                this.recognition.start();
            } catch (e) {
                console.error("Error restarting speech recognition:", e);
                this.isListening = false;
            }
        }
    }
    
    /**
     * Trigger the SOS alert
     * @param {string} phrase - The phrase that triggered the alert
     * @private
     */
    async triggerSOS(phrase) {
        console.log(`SOS triggered by voice command: "${phrase}"`);
        
        if (this.onTriggerCallback) {
            this.onTriggerCallback("voice", phrase);
        }
        
        try {
            const result = await this.alertService.sendSOSAlert("voice");
            console.log("SOS alert sent:", result);
        } catch (error) {
            console.error("Error sending SOS alert:", error);
            
            if (this.onErrorCallback) {
                this.onErrorCallback(`Failed to send SOS alert: ${error.message}`);
            }
        }
    }
    
    /**
     * Set callback for progress updates
     * @param {Function} callback - Progress callback function
     */
    setOnProgress(callback) {
        this.onProgressCallback = callback;
    }
    
    /**
     * Set callback for detector reset
     * @param {Function} callback - Reset callback function
     */
    setOnReset(callback) {
        this.onResetCallback = callback;
    }
    
    /**
     * Set callback for SOS trigger
     * @param {Function} callback - Trigger callback function
     */
    setOnTrigger(callback) {
        this.onTriggerCallback = callback;
    }
    
    /**
     * Set callback for errors
     * @param {Function} callback - Error callback function
     */
    setOnError(callback) {
        this.onErrorCallback = callback;
    }
    
    /**
     * Notify of an error
     * @param {string} message - Error message
     * @private
     */
    notifyError(message) {
        console.error(message);
        
        if (this.onErrorCallback) {
            this.onErrorCallback(message);
        }
    }
    
    /**
     * Check if speech recognition is supported
     * @returns {boolean} True if supported
     */
    isSupported() {
        return !!this.recognition;
    }
    
    /**
     * Reset detector state
     */
    reset() {
        this.lastTriggerTime = 0;
        
        if (this.onResetCallback) {
            this.onResetCallback();
        }
    }
}

// Export a singleton instance
let voiceDetector = null;

function createVoiceDetector(configManager, alertService) {
    if (!voiceDetector) {
        voiceDetector = new VoiceDetector(configManager, alertService);
    }
    return voiceDetector;
}