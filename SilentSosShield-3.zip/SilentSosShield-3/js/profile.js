/**
 * Profile Management
 * Handles user profile viewing and editing
 */

document.addEventListener('DOMContentLoaded', function() {
    loadProfileData();
    
    // Set up form submission handlers
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
    }
    
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', handlePasswordUpdate);
    }
    
    // Initialize feather icons
    feather.replace();
});

/**
 * Load user profile data
 */
async function loadProfileData() {
    try {
        const username = localStorage.getItem('username');
        if (!username) {
            window.location.href = 'login.html';
            return;
        }
        
        // Update current username in dropdown
        const usernameElement = document.getElementById('currentUsername');
        if (usernameElement) {
            usernameElement.textContent = username;
        }
        
        // Get user data from API
        const response = await fetch(`${apiService.baseUrl}/users/${username}`);
        
        if (!response.ok) {
            throw new Error('Unable to load profile data');
        }
        
        const userData = await response.json();
        
        // Fill form with user data
        document.getElementById('username').value = userData.username || '';
        document.getElementById('email').value = userData.email || '';
        document.getElementById('phoneNumber').value = userData.phone_number || '';
        
    } catch (error) {
        console.error('Error loading profile data:', error);
        showAlert('profileAlert', 'Unable to load profile data. Please try again later.', 'danger');
    }
}

/**
 * Handle profile form submission
 * @param {Event} event - Form submission event
 */
async function handleProfileUpdate(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    
    try {
        const username = localStorage.getItem('username');
        if (!username) {
            window.location.href = 'login.html';
            return;
        }
        
        // Update user data via API
        const response = await fetch(`${apiService.baseUrl}/users/${username}/update`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
            },
            body: JSON.stringify({ 
                email, 
                phoneNumber
            })
        });
        
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || 'Profile update failed');
        }
        
        showAlert('profileAlert', 'Profile updated successfully!', 'success');
        
    } catch (error) {
        console.error('Error updating profile:', error);
        showAlert('profileAlert', error.message || 'Failed to update profile. Please try again.', 'danger');
    }
}

/**
 * Handle password form submission
 * @param {Event} event - Form submission event
 */
async function handlePasswordUpdate(event) {
    event.preventDefault();
    
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmNewPassword = document.getElementById('confirmNewPassword').value;
    
    // Validate passwords
    if (newPassword !== confirmNewPassword) {
        showAlert('passwordAlert', 'New passwords do not match', 'danger');
        return;
    }
    
    try {
        const username = localStorage.getItem('username');
        if (!username) {
            window.location.href = 'login.html';
            return;
        }
        
        // Update password via API
        const response = await fetch(`${apiService.baseUrl}/users/${username}/password`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
            },
            body: JSON.stringify({ 
                currentPassword, 
                newPassword 
            })
        });
        
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || 'Password update failed');
        }
        
        // Reset form
        document.getElementById('passwordForm').reset();
        
        showAlert('passwordAlert', 'Password updated successfully!', 'success');
        
    } catch (error) {
        console.error('Error updating password:', error);
        showAlert('passwordAlert', error.message || 'Failed to update password. Please try again.', 'danger');
    }
}

/**
 * Shows an alert message
 * @param {string} elementId - ID of the alert element
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, etc.)
 */
function showAlert(elementId, message, type = 'info') {
    const alertElement = document.getElementById(elementId);
    if (alertElement) {
        alertElement.textContent = message;
        alertElement.classList.remove('d-none', 'alert-success', 'alert-danger', 'alert-info', 'alert-warning');
        alertElement.classList.add(`alert-${type}`);
    }
}