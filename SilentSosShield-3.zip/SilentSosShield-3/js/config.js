/**
 * Configuration Manager
 * Handles storage and retrieval of user configurations
 */
class ConfigManager {
    constructor() {
        this.defaults = {
            pressCount: 3,
            alertMessage: "I need help! This is an emergency.",
            contacts: [],
            gestures: {
                enabled: true,
                shakeEnabled: true,
                tiltEnabled: true,
                shakeThreshold: 15,
                shakeCount: 3,
                tiltThreshold: 45,
                tiltHoldTime: 2000
            },
            voice: {
                enabled: true,
                triggerPhrases: ["help me", "emergency", "get help", "SOS", "danger"],
                confidenceThreshold: 0.6, // Minimum confidence level required (0.0 to 1.0)
                language: 'en-US'
            },
            aiThreat: {
                enabled: true,
                automaticTrigger: true, // Automatically trigger SOS when threat detected
                thresholds: {
                    threatLevel: 80, // Minimum overall threat level to trigger SOS (0-100)
                    running: 15, // Acceleration threshold for detecting running
                    heartRateElevation: 30, // % increase in heart rate that's concerning
                    audioSpike: 3 // Multiple of baseline audio that indicates danger
                },
                weights: {
                    acceleration: 0.3,
                    heartRate: 0.3,
                    audio: 0.3,
                    trendFactor: 0.1
                },
                sensors: {
                    useAccelerometer: true,
                    useHeartRate: true,
                    useAudio: true
                }
            },
            predictiveLearning: {
                enabled: true,
                anomalyThreshold: 60, // Score above which behavior is considered anomalous (0-100)
                learningRate: 0.2, // How quickly new observations affect learned patterns (0-1)
                captureInterval: 60000, // Capture data every 60 seconds
                analysisInterval: 300000, // Analyze patterns every 5 minutes
                maxHistoryLength: 5000, // Maximum number of historical data points to store
                sensitivityAdjustment: 15, // How much to adjust threat thresholds on anomaly (%)
                considerTimeOfDay: true, // Consider time patterns in anomaly detection
                considerLocation: true, // Consider location patterns in anomaly detection
                considerDayOfWeek: true // Consider day of week patterns in anomaly detection
            }
        };
        this.config = this.loadConfig();
    }

    /**
     * Loads configuration from localStorage or uses defaults
     */
    loadConfig() {
        const savedConfig = localStorage.getItem('sosConfig');
        if (savedConfig) {
            try {
                return JSON.parse(savedConfig);
            } catch (e) {
                console.error("Failed to parse saved configuration:", e);
                return {...this.defaults};
            }
        }
        return {...this.defaults};
    }

    /**
     * Saves current configuration to localStorage
     */
    saveConfig() {
        localStorage.setItem('sosConfig', JSON.stringify(this.config));
    }

    /**
     * Updates configuration with new values
     * @param {Object} newConfig - New configuration values
     */
    updateConfig(newConfig) {
        this.config = {...this.config, ...newConfig};
        this.saveConfig();
    }

    /**
     * Gets the current press count setting
     * @returns {number} Current press count
     */
    getPressCount() {
        return this.config.pressCount;
    }

    /**
     * Sets new press count
     * @param {number} count - New press count (3-5)
     */
    setPressCount(count) {
        if (count >= 3 && count <= 5) {
            this.config.pressCount = count;
            this.saveConfig();
        } else {
            throw new Error("Press count must be between 3 and 5");
        }
    }

    /**
     * Gets the current alert message
     * @returns {string} Alert message
     */
    getAlertMessage() {
        return this.config.alertMessage;
    }

    /**
     * Sets new alert message
     * @param {string} message - New alert message
     */
    setAlertMessage(message) {
        if (message && message.trim().length > 0) {
            this.config.alertMessage = message.trim();
            this.saveConfig();
        } else {
            throw new Error("Alert message cannot be empty");
        }
    }

    /**
     * Resets configuration to defaults
     */
    resetConfig() {
        this.config = {...this.defaults};
        this.saveConfig();
    }
    
    /**
     * Gets gesture settings
     * @returns {Object} Gesture settings object
     */
    getGestureSettings() {
        // Ensure defaults if this is from older version
        if (!this.config.gestures) {
            this.config.gestures = {...this.defaults.gestures};
            this.saveConfig();
        }
        return this.config.gestures;
    }
    
    /**
     * Updates gesture settings
     * @param {Object} settings - New gesture settings
     */
    updateGestureSettings(settings) {
        // Ensure we have a gestures object
        if (!this.config.gestures) {
            this.config.gestures = {...this.defaults.gestures};
        }
        
        // Update with new settings
        this.config.gestures = {...this.config.gestures, ...settings};
        this.saveConfig();
    }
    
    /**
     * Checks if gestures are enabled
     * @returns {boolean} True if gestures are enabled
     */
    areGesturesEnabled() {
        return this.getGestureSettings().enabled === true;
    }
    
    /**
     * Enables or disables gesture detection
     * @param {boolean} enabled - Whether gestures should be enabled
     */
    setGesturesEnabled(enabled) {
        this.updateGestureSettings({ enabled: !!enabled });
    }
    
    /**
     * Checks if shake detection is enabled
     * @returns {boolean} True if shake detection is enabled
     */
    isShakeEnabled() {
        return this.getGestureSettings().shakeEnabled === true;
    }
    
    /**
     * Enables or disables shake detection
     * @param {boolean} enabled - Whether shake detection should be enabled
     */
    setShakeEnabled(enabled) {
        this.updateGestureSettings({ shakeEnabled: !!enabled });
    }
    
    /**
     * Checks if tilt detection is enabled
     * @returns {boolean} True if tilt detection is enabled
     */
    isTiltEnabled() {
        return this.getGestureSettings().tiltEnabled === true;
    }
    
    /**
     * Enables or disables tilt detection
     * @param {boolean} enabled - Whether tilt detection should be enabled
     */
    setTiltEnabled(enabled) {
        this.updateGestureSettings({ tiltEnabled: !!enabled });
    }
    
    /**
     * Gets the shake threshold setting
     * @returns {number} Current shake threshold
     */
    getShakeThreshold() {
        return this.getGestureSettings().shakeThreshold;
    }
    
    /**
     * Sets shake sensitivity threshold
     * @param {number} threshold - New shake threshold (5-25)
     */
    setShakeThreshold(threshold) {
        if (threshold >= 5 && threshold <= 25) {
            this.updateGestureSettings({ shakeThreshold: threshold });
        } else {
            throw new Error("Shake threshold must be between 5 and 25");
        }
    }
    
    /**
     * Gets the required shake count setting
     * @returns {number} Current required shake count
     */
    getShakeCount() {
        return this.getGestureSettings().shakeCount;
    }
    
    /**
     * Sets required shake count
     * @param {number} count - New required shake count (2-5)
     */
    setShakeCount(count) {
        if (count >= 2 && count <= 5) {
            this.updateGestureSettings({ shakeCount: count });
        } else {
            throw new Error("Shake count must be between 2 and 5");
        }
    }
    
    /**
     * Gets the tilt threshold setting
     * @returns {number} Current tilt threshold in degrees
     */
    getTiltThreshold() {
        return this.getGestureSettings().tiltThreshold;
    }
    
    /**
     * Sets tilt threshold in degrees
     * @param {number} threshold - New tilt threshold (30-60 degrees)
     */
    setTiltThreshold(threshold) {
        if (threshold >= 30 && threshold <= 60) {
            this.updateGestureSettings({ tiltThreshold: threshold });
        } else {
            throw new Error("Tilt threshold must be between 30 and 60 degrees");
        }
    }
    
    /**
     * Gets the tilt hold time setting
     * @returns {number} Current tilt hold time in milliseconds
     */
    getTiltHoldTime() {
        return this.getGestureSettings().tiltHoldTime;
    }
    
    /**
     * Sets how long tilt must be held to trigger SOS
     * @param {number} time - New hold time in milliseconds (1000-5000)
     */
    setTiltHoldTime(time) {
        if (time >= 1000 && time <= 5000) {
            this.updateGestureSettings({ tiltHoldTime: time });
        } else {
            throw new Error("Tilt hold time must be between 1 and 5 seconds");
        }
    }
    
    /**
     * Gets voice settings
     * @returns {Object} Voice settings object
     */
    getVoiceSettings() {
        // Ensure defaults if this is from older version
        if (!this.config.voice) {
            this.config.voice = {...this.defaults.voice};
            this.saveConfig();
        }
        return this.config.voice;
    }
    
    /**
     * Updates voice settings
     * @param {Object} settings - New voice settings
     */
    updateVoiceSettings(settings) {
        // Ensure we have a voice object
        if (!this.config.voice) {
            this.config.voice = {...this.defaults.voice};
        }
        
        // Update with new settings
        this.config.voice = {...this.config.voice, ...settings};
        this.saveConfig();
    }
    
    /**
     * Checks if voice detection is enabled
     * @returns {boolean} True if voice detection is enabled
     */
    isVoiceEnabled() {
        return this.getVoiceSettings().enabled === true;
    }
    
    /**
     * Enables or disables voice detection
     * @param {boolean} enabled - Whether voice detection should be enabled
     */
    setVoiceEnabled(enabled) {
        this.updateVoiceSettings({ enabled: !!enabled });
    }
    
    /**
     * Gets the voice trigger phrases
     * @returns {Array<string>} List of trigger phrases
     */
    getVoiceTriggerPhrases() {
        return this.getVoiceSettings().triggerPhrases || this.defaults.voice.triggerPhrases;
    }
    
    /**
     * Sets the voice trigger phrases
     * @param {Array<string>} phrases - New list of trigger phrases
     */
    setVoiceTriggerPhrases(phrases) {
        if (!Array.isArray(phrases) || phrases.length === 0) {
            throw new Error("At least one trigger phrase is required");
        }
        
        this.updateVoiceSettings({ triggerPhrases: phrases });
    }
    
    /**
     * Add a voice trigger phrase
     * @param {string} phrase - New trigger phrase to add
     */
    addVoiceTriggerPhrase(phrase) {
        if (!phrase || phrase.trim().length === 0) {
            throw new Error("Trigger phrase cannot be empty");
        }
        
        const phrases = this.getVoiceTriggerPhrases();
        if (!phrases.includes(phrase.trim())) {
            phrases.push(phrase.trim());
            this.updateVoiceSettings({ triggerPhrases: phrases });
        }
    }
    
    /**
     * Remove a voice trigger phrase
     * @param {string} phrase - Trigger phrase to remove
     */
    removeVoiceTriggerPhrase(phrase) {
        const phrases = this.getVoiceTriggerPhrases();
        const index = phrases.indexOf(phrase);
        
        if (index !== -1 && phrases.length > 1) {
            phrases.splice(index, 1);
            this.updateVoiceSettings({ triggerPhrases: phrases });
        } else if (phrases.length <= 1) {
            throw new Error("Cannot remove the last trigger phrase");
        }
    }
    
    /**
     * Gets the voice confidence threshold
     * @returns {number} Confidence threshold (0.0 to 1.0)
     */
    getVoiceConfidenceThreshold() {
        return this.getVoiceSettings().confidenceThreshold || this.defaults.voice.confidenceThreshold;
    }
    
    /**
     * Sets the voice confidence threshold
     * @param {number} threshold - New confidence threshold (0.0 to 1.0)
     */
    setVoiceConfidenceThreshold(threshold) {
        if (threshold < 0.0 || threshold > 1.0) {
            throw new Error("Confidence threshold must be between 0.0 and 1.0");
        }
        
        this.updateVoiceSettings({ confidenceThreshold: threshold });
    }
    
    /**
     * Gets the voice recognition language
     * @returns {string} Language code (e.g. 'en-US')
     */
    getVoiceLanguage() {
        return this.getVoiceSettings().language || this.defaults.voice.language;
    }
    
    /**
     * Sets the voice recognition language
     * @param {string} language - New language code (e.g. 'en-US')
     */
    setVoiceLanguage(language) {
        if (!language || language.trim().length === 0) {
            throw new Error("Language code cannot be empty");
        }
        
        this.updateVoiceSettings({ language: language.trim() });
    }
    
    /**
     * Gets AI threat detection settings
     * @returns {Object} AI threat settings object
     */
    getAIThreatSettings() {
        // Ensure defaults if this is from older version
        if (!this.config.aiThreat) {
            this.config.aiThreat = {...this.defaults.aiThreat};
            this.saveConfig();
        }
        return this.config.aiThreat;
    }
    
    /**
     * Updates AI threat settings
     * @param {Object} settings - New AI threat settings
     */
    updateAIThreatSettings(settings) {
        // Ensure we have an aiThreat object
        if (!this.config.aiThreat) {
            this.config.aiThreat = {...this.defaults.aiThreat};
        }
        
        // Update with new settings
        this.config.aiThreat = {...this.config.aiThreat, ...settings};
        this.saveConfig();
    }
    
    /**
     * Checks if AI threat detection is enabled
     * @returns {boolean} True if AI threat detection is enabled
     */
    isAIThreatEnabled() {
        return this.getAIThreatSettings().enabled === true;
    }
    
    /**
     * Enables or disables AI threat detection
     * @param {boolean} enabled - Whether AI threat detection should be enabled
     */
    setAIThreatEnabled(enabled) {
        this.updateAIThreatSettings({ enabled: !!enabled });
    }
    
    /**
     * Checks if automatic SOS triggering is enabled
     * @returns {boolean} True if automatic triggering is enabled
     */
    isAutomaticTriggerEnabled() {
        return this.getAIThreatSettings().automaticTrigger === true;
    }
    
    /**
     * Enables or disables automatic SOS triggering
     * @param {boolean} enabled - Whether automatic triggering should be enabled
     */
    setAutomaticTriggerEnabled(enabled) {
        this.updateAIThreatSettings({ automaticTrigger: !!enabled });
    }
    
    /**
     * Gets AI threat detection thresholds
     * @returns {Object} Threshold settings object
     */
    getAIThreatThresholds() {
        return this.getAIThreatSettings().thresholds || this.defaults.aiThreat.thresholds;
    }
    
    /**
     * Updates AI threat detection thresholds
     * @param {Object} thresholds - New threshold settings
     */
    updateAIThreatThresholds(thresholds) {
        const currentSettings = this.getAIThreatSettings();
        this.updateAIThreatSettings({ 
            thresholds: {...currentSettings.thresholds, ...thresholds} 
        });
    }
    
    /**
     * Gets AI threat detection sensor usage settings
     * @returns {Object} Sensor usage settings
     */
    getAIThreatSensors() {
        return this.getAIThreatSettings().sensors || this.defaults.aiThreat.sensors;
    }
    
    /**
     * Updates which sensors are used in AI threat detection
     * @param {Object} sensors - Sensor usage settings
     */
    updateAIThreatSensors(sensors) {
        const currentSettings = this.getAIThreatSettings();
        this.updateAIThreatSettings({
            sensors: {...currentSettings.sensors, ...sensors}
        });
    }
    
    /**
     * Gets AI threat detection weighting factors
     * @returns {Object} Weight settings
     */
    getAIThreatWeights() {
        return this.getAIThreatSettings().weights || this.defaults.aiThreat.weights;
    }
    
    /**
     * Updates weighting factors for AI threat detection
     * @param {Object} weights - New weight settings
     */
    updateAIThreatWeights(weights) {
        const currentSettings = this.getAIThreatSettings();
        this.updateAIThreatSettings({
            weights: {...currentSettings.weights, ...weights}
        });
    }
    
    /**
     * Gets predictive learning settings
     * @returns {Object} Predictive learning settings
     */
    getPredictiveLearningSettings() {
        // Ensure defaults if this is from older version
        if (!this.config.predictiveLearning) {
            this.config.predictiveLearning = {...this.defaults.predictiveLearning};
            this.saveConfig();
        }
        return this.config.predictiveLearning;
    }
    
    /**
     * Updates predictive learning settings
     * @param {Object} settings - New predictive learning settings
     */
    updatePredictiveLearningSettings(settings) {
        // Ensure we have a predictiveLearning object
        if (!this.config.predictiveLearning) {
            this.config.predictiveLearning = {...this.defaults.predictiveLearning};
        }
        
        // Update with new settings
        this.config.predictiveLearning = {...this.config.predictiveLearning, ...settings};
        this.saveConfig();
    }
    
    /**
     * Checks if predictive learning is enabled
     * @returns {boolean} True if predictive learning is enabled
     */
    isPredictiveLearningEnabled() {
        return this.getPredictiveLearningSettings().enabled === true;
    }
    
    /**
     * Enables or disables predictive learning
     * @param {boolean} enabled - Whether predictive learning should be enabled
     */
    setPredictiveLearningEnabled(enabled) {
        this.updatePredictiveLearningSettings({ enabled: !!enabled });
    }
    
    /**
     * Gets the anomaly threshold for predictive learning
     * @returns {number} Anomaly threshold (0-100)
     */
    getAnomalyThreshold() {
        return this.getPredictiveLearningSettings().anomalyThreshold;
    }
    
    /**
     * Sets the anomaly threshold for predictive learning
     * @param {number} threshold - New anomaly threshold (0-100)
     */
    setAnomalyThreshold(threshold) {
        if (threshold < 0 || threshold > 100) {
            throw new Error("Anomaly threshold must be between 0 and 100");
        }
        
        this.updatePredictiveLearningSettings({ anomalyThreshold: threshold });
    }
    
    /**
     * Gets the learning rate for predictive learning
     * @returns {number} Learning rate (0-1)
     */
    getLearningRate() {
        return this.getPredictiveLearningSettings().learningRate;
    }
    
    /**
     * Sets the learning rate for predictive learning
     * @param {number} rate - New learning rate (0-1)
     */
    setLearningRate(rate) {
        if (rate < 0 || rate > 1) {
            throw new Error("Learning rate must be between 0 and 1");
        }
        
        this.updatePredictiveLearningSettings({ learningRate: rate });
    }
}

// Export a singleton instance
const configManager = new ConfigManager();
