/**
 * Authentication Service
 * Handles user authentication, registration, and session management
 */
class AuthService {
    constructor() {
        this.isLoggedIn = false;
        this.currentUser = null;
        
        // Check if user is already logged in
        this.checkAuthStatus();
        
        // If we're on the login page, set up the login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', this.handleLogin.bind(this));
        }
        
        // If we're on the registration page, set up the registration form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', this.handleRegistration.bind(this));
        }
    }
    
    /**
     * Check if user is already authenticated based on localStorage token
     */
    async checkAuthStatus() {
        const token = localStorage.getItem('authToken');
        const username = localStorage.getItem('username');
        
        if (token && username) {
            try {
                // Try to get user data to validate token
                const userData = await this.getUserData(username);
                if (userData) {
                    this.isLoggedIn = true;
                    this.currentUser = userData;
                    
                    // If on login page, redirect to main app
                    if (window.location.pathname.includes('login.html') || 
                        window.location.pathname.includes('register.html')) {
                        window.location.href = 'index.html';
                    }
                }
            } catch (error) {
                console.error('Authentication validation failed:', error);
                this.logout();
            }
        } else {
            // If not authenticated and on main app page, redirect to login
            const onMainApp = !window.location.pathname.includes('login.html') && 
                             !window.location.pathname.includes('register.html');
            
            if (onMainApp) {
                window.location.href = 'login.html';
            }
        }
    }
    
    /**
     * Handle login form submission
     * @param {Event} event - Form submission event
     */
    async handleLogin(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const loginAlert = document.getElementById('loginAlert');
        
        try {
            // For demo purposes, accept any password for demo_user
            if (username === 'demo_user') {
                this.setAuthenticated('demo_token', username);
                window.location.href = 'index.html';
                return;
            }
            
            // Make API call to authenticate
            const response = await fetch(`${apiService.baseUrl}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Login failed');
            }
            
            // Set authentication data and redirect
            this.setAuthenticated(data.token, username);
            window.location.href = 'index.html';
            
        } catch (error) {
            console.error('Login error:', error);
            loginAlert.textContent = error.message || 'Invalid username or password';
            loginAlert.classList.remove('d-none', 'alert-success');
            loginAlert.classList.add('alert-danger');
        }
    }
    
    /**
     * Handle registration form submission
     * @param {Event} event - Form submission event
     */
    async handleRegistration(event) {
        event.preventDefault();
        
        const username = document.getElementById('reg-username').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const phoneNumber = document.getElementById('reg-phone').value.trim();
        const password = document.getElementById('reg-password').value;
        const confirmPassword = document.getElementById('reg-confirm-password').value;
        const registerAlert = document.getElementById('registerAlert');
        
        // Validate inputs
        if (password !== confirmPassword) {
            registerAlert.textContent = 'Passwords do not match';
            registerAlert.classList.remove('d-none', 'alert-success');
            registerAlert.classList.add('alert-danger');
            return;
        }
        
        try {
            // Make API call to register
            const response = await fetch(`${apiService.baseUrl}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, email, password, phoneNumber }),
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'Registration failed');
            }
            
            // Show success message
            registerAlert.textContent = 'Registration successful! Redirecting to login...';
            registerAlert.classList.remove('d-none', 'alert-danger');
            registerAlert.classList.add('alert-success');
            
            // Redirect to login page after a short delay
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
            
        } catch (error) {
            console.error('Registration error:', error);
            registerAlert.textContent = error.message || 'Registration failed. Please try again.';
            registerAlert.classList.remove('d-none', 'alert-success');
            registerAlert.classList.add('alert-danger');
        }
    }
    
    /**
     * Get user data by username
     * @param {string} username - Username to get data for
     * @returns {Promise<Object>} User data
     */
    async getUserData(username) {
        try {
            // Use the API service to get user data
            return await apiService.getCurrentUser();
        } catch (error) {
            console.error('Error fetching user data:', error);
            throw error;
        }
    }
    
    /**
     * Set authentication data in localStorage
     * @param {string} token - Authentication token
     * @param {string} username - Username
     */
    setAuthenticated(token, username) {
        localStorage.setItem('authToken', token);
        localStorage.setItem('username', username);
        this.isLoggedIn = true;
    }
    
    /**
     * Log the user out
     */
    logout() {
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
        this.isLoggedIn = false;
        this.currentUser = null;
        window.location.href = 'login.html';
    }
}

// Initialize the auth service
const authService = new AuthService();

// Add a global logout function for use in the main app
function logout() {
    authService.logout();
}