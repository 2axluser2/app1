/**
 * Contact Manager
 * Handles adding, removing, and retrieving emergency contacts
 * with support for both local storage and API backend
 */
class ContactManager {
    constructor(configManager) {
        this.configManager = configManager;
        this.contacts = [];
        
        // Load contacts from localStorage
        this.loadContacts();
        
        // Try to load contacts from API if available
        this.loadContactsFromAPI();
    }
    
    /**
     * Load contacts from localStorage
     * @private
     */
    loadContacts() {
        this.contacts = this.configManager.config.contacts || [];
    }
    
    /**
     * Save contacts to localStorage
     * @private
     */
    saveContacts() {
        this.configManager.config.contacts = this.contacts;
        this.configManager.saveConfig();
    }
    
    /**
     * Try to load contacts from API if available
     * @private
     */
    async loadContactsFromAPI() {
        try {
            if (typeof apiService !== 'undefined') {
                const apiContacts = await apiService.getContacts();
                
                if (apiContacts && apiContacts.length > 0) {
                    console.log('Loaded contacts from API');
                    
                    // Merge with existing contacts, prioritizing API data
                    const apiContactIds = apiContacts.map(c => c.id);
                    
                    // Keep local contacts that aren't in the API data
                    const localOnlyContacts = this.contacts.filter(
                        c => !apiContactIds.includes(c.id)
                    );
                    
                    // Combine and update local cache
                    this.contacts = [...apiContacts, ...localOnlyContacts];
                    this.saveContacts();
                }
            }
        } catch (error) {
            console.error('Failed to load contacts from API:', error);
            // Continue with local contacts
        }
    }

    /**
     * Gets all emergency contacts
     * @returns {Array} List of contacts
     */
    getContacts() {
        return this.contacts;
    }

    /**
     * Adds a new emergency contact
     * @param {Object} contact - Contact object with name and phone
     * @returns {Promise<string>} ID of the new contact
     */
    async addContact(contact) {
        if (!contact.name || !contact.phone) {
            throw new Error("Contact must have name and phone number");
        }

        // Validate phone number format
        const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
        if (!phoneRegex.test(contact.phone)) {
            throw new Error("Invalid phone number format");
        }

        // Try to add via API first
        try {
            if (typeof apiService !== 'undefined') {
                const apiContact = await apiService.addContact({
                    name: contact.name.trim(),
                    phone: contact.phone.trim(),
                    relationship: contact.relationship
                });
                
                if (apiContact && apiContact.id) {
                    // Add to local cache
                    this.contacts.push(apiContact);
                    this.saveContacts();
                    return apiContact.id;
                }
            }
        } catch (error) {
            console.error('Failed to add contact via API, falling back to local:', error);
            // Continue with local storage
        }
        
        // Create a new contact with unique ID
        const newContact = {
            id: Date.now().toString(),
            name: contact.name.trim(),
            phone: contact.phone.trim(),
            relationship: contact.relationship || null,
            created_at: new Date().toISOString()
        };

        // Add to the contacts array
        this.contacts.push(newContact);
        this.saveContacts();

        return newContact.id;
    }

    /**
     * Removes a contact by ID
     * @param {string} contactId - ID of the contact to remove
     * @returns {Promise<boolean>} Success status
     */
    async removeContact(contactId) {
        // Try to remove via API first
        try {
            if (typeof apiService !== 'undefined') {
                const success = await apiService.removeContact(contactId);
                if (success) {
                    // Remove from local cache
                    this.contacts = this.contacts.filter(contact => contact.id !== contactId);
                    this.saveContacts();
                    return true;
                }
            }
        } catch (error) {
            console.error('Failed to remove contact via API, falling back to local:', error);
            // Continue with local storage
        }
        
        const initialLength = this.contacts.length;
        this.contacts = this.contacts.filter(contact => contact.id !== contactId);
        
        if (this.contacts.length === initialLength) {
            return false; // Contact not found
        }
        
        this.saveContacts();
        return true;
    }

    /**
     * Gets a contact by ID
     * @param {string} contactId - ID of the contact to get
     * @returns {Object|null} Contact object or null if not found
     */
    getContactById(contactId) {
        return this.contacts.find(contact => contact.id === contactId) || null;
    }

    /**
     * Validates if there are enough contacts to send alerts
     * @returns {boolean} True if there's at least one contact
     */
    hasValidContacts() {
        return this.contacts.length > 0;
    }
}

// Create a singleton instance with the configManager
const contactManager = new ContactManager(configManager);
