/**
 * AI Threat Detector
 * Uses contextual analysis with multiple sensors to assess risk
 * and automatically trigger SOS when threat is detected
 */
class ThreatDetector {
    constructor(configManager, alertService) {
        this.configManager = configManager;
        this.alertService = alertService;
        this.active = false;
        this.onProgressCallback = null;
        this.onResetCallback = null;
        this.onTriggerCallback = null;
        this.onErrorCallback = null;
        
        // Sensor reading values
        this.movementType = 'stationary';  // stationary, walking, running, erratic
        this.heartRate = 70;               // in beats per minute
        this.heartRateBaseline = 0;        // baseline heart rate
        this.audioLevel = 0;               // 0-100 scale
        
        // Threat analysis
        this.threatLevel = 0;              // 0-100 scale
        this.lastThreatLevel = 0;
        this.environmentBaseline = {
            audio: 0,
            movement: 0
        };
        
        // Interval IDs
        this.analyzeInterval = null;
        this.accelerometerDataInterval = null;
        this.audioMonitoringInterval = null;
        this.heartRateInterval = null;
        
        // Threat data
        this.accelerationData = [];
        this.audioData = [];
        this.heartRateData = [];
        
        // Analysis config
        this.settings = configManager.getAIThreatSettings();
    }
    
    /**
     * Starts the threat detection system
     */
    start() {
        if (this.active) return;
        
        this.active = true;
        this.threatLevel = 0;
        this.lastThreatLevel = 0;
        
        // Start baselining to establish normal environment
        this.startBaselining();
        
        // Attach necessary sensors
        this.attachSensors();
        
        // Start monitoring and analysis
        this.analyzeInterval = setInterval(() => {
            this.analyzeThreatLevel();
        }, 1000);
        
        console.log('Threat detector started');
    }
    
    /**
     * Stops the threat detection system
     */
    stop() {
        if (!this.active) return;
        
        this.active = false;
        
        // Clear intervals
        clearInterval(this.analyzeInterval);
        clearInterval(this.accelerometerDataInterval);
        clearInterval(this.audioMonitoringInterval);
        clearInterval(this.heartRateInterval);
        
        // Reset state
        this.reset();
        
        // Detach sensors
        this.detachSensors();
        
        console.log('Threat detector stopped');
    }
    
    /**
     * Collect baseline readings for normal environment
     */
    startBaselining() {
        this.heartRateBaseline = 0;
        this.environmentBaseline.audio = 0;
        this.environmentBaseline.movement = 0;
        
        // Collect 5 seconds of data for baselining
        console.log('Establishing baseline readings...');
        
        // Set initial values
        this.heartRateBaseline = 70; // Typical resting heart rate
        this.environmentBaseline.audio = 10; // Typical ambient noise in quiet environment
        
        setTimeout(() => {
            console.log('Baseline established:', {
                heartRate: this.heartRateBaseline,
                audio: this.environmentBaseline.audio,
                movement: this.environmentBaseline.movement
            });
        }, 5000);
    }
    
    /**
     * Attach sensors and event listeners
     * @private
     */
    attachSensors() {
        const sensors = this.settings.sensors;
        
        // Motion sensors for movement detection
        if (sensors.useAccelerometer) {
            try {
                if ('DeviceMotionEvent' in window) {
                    window.addEventListener('devicemotion', this.handleAcceleration.bind(this));
                    
                    // Also set interval for processing motion data
                    this.accelerometerDataInterval = setInterval(() => {
                        // In a real app, this would process real data
                        // Here we'll simulate random movements
                        const randomActivity = Math.random();
                        if (randomActivity > 0.95) {
                            this.movementType = 'running';
                        } else if (randomActivity > 0.8) {
                            this.movementType = 'walking';
                        } else if (randomActivity > 0.75) {
                            this.movementType = 'erratic';
                        } else {
                            this.movementType = 'stationary';
                        }
                    }, 2000);
                } else {
                    console.warn('Device motion not supported');
                    this.movementType = 'stationary';
                }
            } catch (error) {
                this.notifyError('Failed to initialize motion detection: ' + error.message);
            }
        }
        
        // Audio monitoring
        if (sensors.useAudio) {
            try {
                this.startAudioMonitoring();
            } catch (error) {
                this.notifyError('Failed to initialize audio monitoring: ' + error.message);
            }
        }
        
        // Heart rate monitoring (simulated for this demo)
        if (sensors.useHeartRate) {
            try {
                this.simulateHeartRate();
            } catch (error) {
                this.notifyError('Failed to initialize heart rate monitoring: ' + error.message);
            }
        }
    }
    
    /**
     * Detach sensors and event listeners
     * @private
     */
    detachSensors() {
        // Remove motion event listener
        if (this.settings.sensors.useAccelerometer && 'DeviceMotionEvent' in window) {
            window.removeEventListener('devicemotion', this.handleAcceleration);
        }
        
        // Stop audio monitoring
        if (this.settings.sensors.useAudio) {
            this.stopAudioMonitoring();
        }
    }
    
    /**
     * Handle accelerometer data to detect movement patterns
     * @param {DeviceMotionEvent} event - Motion event
     * @private
     */
    handleAcceleration(event) {
        if (!this.active) return;
        
        // Real implementation would analyze motion patterns
        // In this demo, movement type is simulated above
    }
    
    /**
     * Start monitoring ambient audio levels
     * @private
     */
    startAudioMonitoring() {
        // In a real app, this would request microphone access
        // For our demo, we'll simulate audio level changes
        
        this.audioMonitoringInterval = setInterval(() => {
            // Simulate audio level (normally quiet with occasional spikes)
            const baseLevel = this.environmentBaseline.audio || 10;
            const randomFactor = Math.random();
            
            if (randomFactor > 0.9) {
                // Occasional loud spike (screaming, crashes, etc)
                this.audioLevel = baseLevel * (3 + Math.random() * 3);
            } else if (randomFactor > 0.7) {
                // Moderate noise (conversation, traffic)
                this.audioLevel = baseLevel * (1.5 + Math.random() * 1.5);
            } else {
                // Mostly ambient noise
                this.audioLevel = baseLevel * (0.8 + Math.random() * 0.4);
            }
        }, 2000);
    }
    
    /**
     * Stop audio monitoring
     * @private
     */
    stopAudioMonitoring() {
        if (this.audioMonitoringInterval) {
            clearInterval(this.audioMonitoringInterval);
            this.audioMonitoringInterval = null;
        }
    }
    
    /**
     * Simulate heart rate data for demo
     * In a real app, this would be replaced with actual heart rate sensor data
     * @private
     */
    simulateHeartRate() {
        this.heartRateInterval = setInterval(() => {
            // Base heart rate depends on movement
            let baseRate = this.heartRateBaseline || 70;
            
            switch (this.movementType) {
                case 'running':
                    // Running significantly elevates heart rate
                    baseRate = baseRate * (1.7 + Math.random() * 0.3); // 70% to 100% increase
                    break;
                case 'walking':
                    // Walking moderately elevates heart rate
                    baseRate = baseRate * (1.2 + Math.random() * 0.2); // 20% to 40% increase
                    break;
                case 'erratic':
                    // Erratic movement can indicate panic or distress
                    baseRate = baseRate * (1.4 + Math.random() * 0.4); // 40% to 80% increase
                    break;
                default:
                    // Stationary - normal variance in heart rate
                    baseRate = baseRate * (0.9 + Math.random() * 0.2); // 10% decrease to 10% increase
            }
            
            // Apply a stress factor based on audio (loud noises can trigger fight/flight)
            const audioStressFactor = this.audioLevel > (this.environmentBaseline.audio * 2) ? 
                                     1.1 + (Math.random() * 0.1) : 1.0;
            
            this.heartRate = Math.round(baseRate * audioStressFactor);
        }, 3000);
    }
    
    /**
     * Analyze all sensor data to determine threat level
     * @private
     */
    analyzeThreatLevel() {
        if (!this.active) return;
        
        const weights = this.settings.weights;
        const thresholds = this.settings.thresholds;
        let threatScore = 0;
        
        // 1. Movement analysis
        let movementScore = 0;
        if (this.movementType === 'running') {
            movementScore = 80 + Math.random() * 20; // 80-100%
        } else if (this.movementType === 'erratic') {
            movementScore = 70 + Math.random() * 20; // 70-90%
        } else if (this.movementType === 'walking') {
            movementScore = 20 + Math.random() * 20; // 20-40%
        } else {
            movementScore = Math.random() * 10; // 0-10%
        }
        
        // 2. Heart rate analysis
        let heartRateScore = 0;
        if (this.heartRateBaseline > 0) {
            const elevation = (this.heartRate - this.heartRateBaseline) / this.heartRateBaseline * 100;
            
            if (elevation >= thresholds.heartRateElevation) {
                // Above threshold - potential concern
                const severity = Math.min(100, elevation / thresholds.heartRateElevation * 100);
                heartRateScore = severity;
            } else {
                // Below threshold - likely normal
                heartRateScore = (elevation / thresholds.heartRateElevation) * 30; // Max 30% if almost at threshold
            }
        }
        
        // 3. Audio analysis
        let audioScore = 0;
        if (this.environmentBaseline.audio > 0) {
            const audioRatio = this.audioLevel / this.environmentBaseline.audio;
            
            if (audioRatio >= thresholds.audioSpike) {
                // Above threshold - potential danger
                const severity = Math.min(100, (audioRatio / thresholds.audioSpike) * 100);
                audioScore = severity;
            } else {
                // Below threshold - likely normal
                audioScore = (audioRatio / thresholds.audioSpike) * 30; // Max 30% if almost at threshold
            }
        }
        
        // 4. Combine scores based on weighting factors
        threatScore = (
            movementScore * weights.acceleration +
            heartRateScore * weights.heartRate +
            audioScore * weights.audio
        ) / (weights.acceleration + weights.heartRate + weights.audio);
        
        // 5. Apply trend factor (sudden changes are more concerning than gradual ones)
        const rateOfChange = Math.abs(threatScore - this.lastThreatLevel);
        const trendFactor = 1 + (rateOfChange / 100) * weights.trendFactor;
        threatScore = Math.min(100, threatScore * trendFactor);
        
        // Round to integer
        this.lastThreatLevel = this.threatLevel;
        this.threatLevel = Math.round(threatScore);
        
        // Update progress
        if (this.onProgressCallback) {
            this.onProgressCallback(this.threatLevel, {
                movement: movementScore,
                heartRate: heartRateScore,
                audio: audioScore
            });
        }
        
        // Check if threat level exceeds threshold and automatic triggering is enabled
        if (this.threatLevel >= thresholds.threatLevel && this.settings.automaticTrigger) {
            this.triggerSOS();
        }
    }
    
    /**
     * Trigger SOS alert
     * @private
     */
    async triggerSOS() {
        if (this.onTriggerCallback) {
            // Calculate context information
            const heartRateElevation = this.heartRateBaseline > 0 ? 
                Math.round((this.heartRate - this.heartRateBaseline) / this.heartRateBaseline * 100) : 0;
                
            const audioElevation = this.environmentBaseline.audio > 0 ? 
                parseFloat((this.audioLevel / this.environmentBaseline.audio).toFixed(1)) : 1.0;
            
            // Provide context about what triggered the alert
            const context = {
                threatLevel: this.threatLevel,
                movementType: this.movementType,
                heartRate: this.heartRate,
                heartRateElevation: heartRateElevation,
                audioLevel: Math.round(this.audioLevel),
                audioElevation: audioElevation
            };
            
            this.onTriggerCallback('ai_threat', context);
        }
        
        try {
            await this.alertService.sendSOSAlert('ai_threat');
        } catch (error) {
            this.notifyError('Failed to send SOS alert: ' + error.message);
        }
    }
    
    /**
     * Set callback for progress updates
     * @param {Function} callback - Function to call with threat level updates
     */
    setOnProgress(callback) {
        this.onProgressCallback = callback;
    }
    
    /**
     * Set callback for detector reset
     * @param {Function} callback - Function to call when detector is reset
     */
    setOnReset(callback) {
        this.onResetCallback = callback;
    }
    
    /**
     * Set callback for SOS trigger
     * @param {Function} callback - Function to call when SOS is triggered
     */
    setOnTrigger(callback) {
        this.onTriggerCallback = callback;
    }
    
    /**
     * Set callback for errors
     * @param {Function} callback - Function to call when errors occur
     */
    setOnError(callback) {
        this.onErrorCallback = callback;
    }
    
    /**
     * Notify of an error
     * @param {string} message - Error message
     * @private
     */
    notifyError(message) {
        console.error('Threat Detector Error:', message);
        if (this.onErrorCallback) {
            this.onErrorCallback(message);
        }
    }
    
    /**
     * Update threat detection settings
     * @param {Object} settings - New settings
     */
    updateSettings(settings) {
        // Get current settings
        const currentSettings = this.configManager.getAIThreatSettings();
        
        // Apply updates
        if (settings.thresholds) {
            currentSettings.thresholds = {...currentSettings.thresholds, ...settings.thresholds};
        }
        if (settings.sensors) {
            currentSettings.sensors = {...currentSettings.sensors, ...settings.sensors};
        }
        if (settings.weights) {
            currentSettings.weights = {...currentSettings.weights, ...settings.weights};
        }
        
        // Update internal settings
        this.settings = currentSettings;
        
        // Restart detection if active
        if (this.active) {
            this.stop();
            this.start();
        }
    }
    
    /**
     * Simulate threat scenario for testing
     * @param {string} scenario - Predefined scenario to simulate
     */
    simulateThreatScenario(scenario) {
        if (!this.active) {
            console.warn('Cannot simulate scenario while detector is inactive');
            return;
        }
        
        console.log(`Simulating ${scenario} scenario`);
        
        // Stop any existing intervals
        clearInterval(this.accelerometerDataInterval);
        clearInterval(this.audioMonitoringInterval);
        clearInterval(this.heartRateInterval);
        
        switch (scenario) {
            case 'running':
                // Simulate running away (high movement, elevated heart rate)
                this.movementType = 'running';
                this.heartRate = Math.round(this.heartRateBaseline * 1.8); // 80% increase
                this.audioLevel = this.environmentBaseline.audio * 1.5; // 50% increase in noise
                break;
                
            case 'attack':
                // Simulate attack (erratic movement, high heart rate, loud noises)
                this.movementType = 'erratic';
                this.heartRate = Math.round(this.heartRateBaseline * 2.0); // 100% increase
                this.audioLevel = this.environmentBaseline.audio * 4.0; // 400% increase in noise
                break;
                
            case 'accident':
                // Simulate accident (sudden movement then stationary, elevated heart rate)
                this.movementType = 'stationary';
                this.heartRate = Math.round(this.heartRateBaseline * 1.6); // 60% increase
                this.audioLevel = this.environmentBaseline.audio * 2.5; // 250% increase then quiet
                
                // Simulate initial impact
                setTimeout(() => {
                    this.audioLevel = this.environmentBaseline.audio * 5.0; // 500% increase (crash sound)
                    
                    // Then simulate aftermath
                    setTimeout(() => {
                        this.audioLevel = this.environmentBaseline.audio * 0.5; // Quiet aftermath
                    }, 2000);
                }, 1000);
                break;
                
            default:
                console.warn('Unknown scenario:', scenario);
                return;
        }
        
        // Force immediate threat analysis
        this.analyzeThreatLevel();
        
        // Restart normal simulation after a short delay
        setTimeout(() => {
            this.attachSensors();
        }, 10000);
    }
    
    /**
     * Resets the threat state to normal
     */
    reset() {
        this.threatLevel = 0;
        this.lastThreatLevel = 0;
        this.movementType = 'stationary';
        this.heartRate = this.heartRateBaseline || 70;
        this.audioLevel = this.environmentBaseline.audio || 10;
        
        if (this.onResetCallback) {
            this.onResetCallback();
        }
    }
}

/**
 * Creates a threat detector instance
 * @param {ConfigManager} configManager - Configuration manager
 * @param {AlertService} alertService - Alert service for sending SOS
 * @returns {ThreatDetector} Threat detector instance
 */
function createThreatDetector(configManager, alertService) {
    return new ThreatDetector(configManager, alertService);
}