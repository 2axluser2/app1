/**
 * Alert Priority System
 * Handles threat prioritization, real-time incident reports, and alert management
 */
class AlertPrioritySystem {
    constructor(configManager, alertService) {
        this.configManager = configManager;
        this.alertService = alertService;
        
        // Incident log storage
        this.incidents = [];
        this.maxIncidents = 100; // Maximum number of incidents to store
        
        // Priority thresholds
        this.thresholds = {
            low: 30,    // 30-59 = Low priority
            medium: 60, // 60-84 = Medium priority
            high: 85    // 85+ = High priority
        };
        
        // Load past incidents if available
        this.loadIncidents();
        
        // Active incident tracking
        this.activeIncidents = {};
        this.activeIncidentCounter = 0;
        
        // Registered listeners for real-time updates
        this.listeners = [];
        
        // Automatic priority escalation rules (time-based)
        this.escalationRules = {
            // An incident will escalate from low to medium if unresolved after 5 minutes
            lowToMedium: 5 * 60 * 1000,
            // An incident will escalate from medium to high if unresolved after 10 minutes
            mediumToHigh: 10 * 60 * 1000
        };
        
        // Start the escalation checker
        this.escalationInterval = setInterval(() => this.checkEscalations(), 60000); // Check every minute
    }
    
    /**
     * Load incidents from localStorage
     * @private
     */
    loadIncidents() {
        try {
            const savedIncidents = localStorage.getItem('sosIncidents');
            if (savedIncidents) {
                this.incidents = JSON.parse(savedIncidents);
                console.log(`Loaded ${this.incidents.length} historical incidents`);
            }
        } catch (error) {
            console.error('Failed to load incident history:', error);
            this.incidents = [];
        }
    }
    
    /**
     * Save incidents to localStorage
     * @private
     */
    saveIncidents() {
        try {
            // Keep only the maximum number of incidents
            if (this.incidents.length > this.maxIncidents) {
                this.incidents = this.incidents.slice(this.incidents.length - this.maxIncidents);
            }
            
            localStorage.setItem('sosIncidents', JSON.stringify(this.incidents));
        } catch (error) {
            console.error('Failed to save incident history:', error);
        }
    }
    
    /**
     * Calculate priority level based on score
     * @param {number} score - Threat score (0-100)
     * @returns {string} Priority level (low, medium, high)
     */
    calculatePriority(score) {
        if (score >= this.thresholds.high) {
            return 'high';
        } else if (score >= this.thresholds.medium) {
            return 'medium';
        } else if (score >= this.thresholds.low) {
            return 'low';
        } else {
            return 'info'; // Below threshold for a real incident
        }
    }
    
    /**
     * Log a new incident
     * @param {Object} incident - Incident data
     * @param {string} incident.type - Type of incident (threat_detected, anomaly_detected, sos_triggered)
     * @param {number} incident.score - Threat score (0-100)
     * @param {string} incident.source - Source of the incident (accelerometer, heart_rate, audio, power_button, etc.)
     * @param {string} incident.description - Human-readable description
     * @param {Object} incident.data - Additional data specific to the incident type
     * @returns {string} Incident ID
     */
    logIncident(incident) {
        // Generate incident ID
        const incidentId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
        
        // Calculate priority
        const priority = this.calculatePriority(incident.score);
        
        // Timestamp the incident
        const timestamp = new Date();
        
        // Create the full incident record
        const incidentRecord = {
            id: incidentId,
            timestamp: timestamp,
            type: incident.type,
            score: incident.score,
            priority: priority,
            source: incident.source,
            description: incident.description,
            data: incident.data || {},
            status: 'active',
            escalationLevel: 0, // Track how many times it has escalated
            createdAt: timestamp,
            updatedAt: timestamp,
            resolvedAt: null
        };
        
        // Add to active incidents
        this.activeIncidents[incidentId] = incidentRecord;
        this.activeIncidentCounter++;
        
        // Add to incident history
        this.incidents.push(incidentRecord);
        this.saveIncidents();
        
        // Notify all listeners
        this.notifyListeners('incident_logged', incidentRecord);
        
        // For high priority incidents, also trigger an immediate notification
        if (priority === 'high') {
            this.notifyListeners('high_priority_incident', incidentRecord);
            
            // Automatically trigger SOS for high priority incidents if auto-trigger is enabled
            if (this.configManager.isAutomaticTriggerEnabled()) {
                this.triggerSOS(incidentRecord);
            }
        }
        
        return incidentId;
    }
    
    /**
     * Update an existing incident
     * @param {string} incidentId - ID of the incident to update
     * @param {Object} updates - Fields to update
     * @returns {boolean} Success indicator
     */
    updateIncident(incidentId, updates) {
        // Check if the incident exists
        const incident = this.activeIncidents[incidentId];
        if (!incident) {
            console.error(`Cannot update incident ${incidentId}: not found`);
            return false;
        }
        
        // Apply updates
        Object.keys(updates).forEach(key => {
            if (key !== 'id' && key !== 'createdAt') { // Don't allow changing these
                incident[key] = updates[key];
            }
        });
        
        // Update timestamp
        incident.updatedAt = new Date();
        
        // If resolving the incident, set resolved timestamp and remove from active
        if (updates.status === 'resolved') {
            incident.resolvedAt = incident.updatedAt;
            delete this.activeIncidents[incidentId];
            this.activeIncidentCounter--;
        }
        
        // If changing priority, notify listeners
        if (updates.priority) {
            this.notifyListeners('priority_changed', incident);
            
            // If escalated to high, trigger special notification
            if (updates.priority === 'high' && incident.priority !== 'high') {
                this.notifyListeners('high_priority_incident', incident);
                
                // Automatically trigger SOS for newly high priority incidents if auto-trigger is enabled
                if (this.configManager.isAutomaticTriggerEnabled()) {
                    this.triggerSOS(incident);
                }
            }
        }
        
        // Update the incident in the history array as well
        const historyIndex = this.incidents.findIndex(inc => inc.id === incidentId);
        if (historyIndex !== -1) {
            this.incidents[historyIndex] = {...incident};
        }
        
        // Save updated incidents
        this.saveIncidents();
        
        // Notify all listeners of the update
        this.notifyListeners('incident_updated', incident);
        
        return true;
    }
    
    /**
     * Resolve an incident
     * @param {string} incidentId - ID of the incident to resolve 
     * @param {string} resolution - Resolution description
     * @returns {boolean} Success indicator
     */
    resolveIncident(incidentId, resolution) {
        return this.updateIncident(incidentId, {
            status: 'resolved',
            resolution: resolution || 'Manually resolved'
        });
    }
    
    /**
     * Check for incidents that need priority escalation
     * @private
     */
    checkEscalations() {
        const now = new Date();
        
        // Loop through active incidents
        Object.values(this.activeIncidents).forEach(incident => {
            // Calculate how long the incident has been active
            const incidentAge = now - new Date(incident.createdAt);
            
            // Check for escalation conditions
            if (incident.priority === 'low' && 
                incidentAge >= this.escalationRules.lowToMedium &&
                incident.escalationLevel === 0) {
                
                // Escalate from low to medium
                this.updateIncident(incident.id, {
                    priority: 'medium',
                    escalationLevel: 1,
                    description: incident.description + ' (Escalated due to time)'
                });
                
                console.log(`Escalated incident ${incident.id} from low to medium priority`);
            }
            else if (incident.priority === 'medium' && 
                    incidentAge >= this.escalationRules.lowToMedium + this.escalationRules.mediumToHigh &&
                    incident.escalationLevel === 1) {
                
                // Escalate from medium to high
                this.updateIncident(incident.id, {
                    priority: 'high',
                    escalationLevel: 2,
                    description: incident.description + ' (Escalated to high priority due to time)'
                });
                
                console.log(`Escalated incident ${incident.id} from medium to high priority`);
            }
        });
    }
    
    /**
     * Register a listener for real-time updates
     * @param {Function} callback - Function to call with updates
     */
    registerListener(callback) {
        this.listeners.push(callback);
    }
    
    /**
     * Remove a listener
     * @param {Function} callback - Function to remove
     */
    removeListener(callback) {
        const index = this.listeners.indexOf(callback);
        if (index !== -1) {
            this.listeners.splice(index, 1);
        }
    }
    
    /**
     * Notify all listeners of an event
     * @param {string} eventType - Type of event
     * @param {Object} data - Event data
     * @private
     */
    notifyListeners(eventType, data) {
        this.listeners.forEach(listener => {
            try {
                listener(eventType, data);
            } catch (error) {
                console.error('Error in incident listener:', error);
            }
        });
    }
    
    /**
     * Get all incidents, optionally filtered
     * @param {Object} filters - Optional filters
     * @param {string} filters.priority - Filter by priority
     * @param {string} filters.status - Filter by status
     * @param {string} filters.type - Filter by incident type
     * @returns {Array} Filtered incidents
     */
    getIncidents(filters = {}) {
        let result = [...this.incidents];
        
        // Apply filters
        if (filters.priority) {
            result = result.filter(inc => inc.priority === filters.priority);
        }
        
        if (filters.status) {
            result = result.filter(inc => inc.status === filters.status);
        }
        
        if (filters.type) {
            result = result.filter(inc => inc.type === filters.type);
        }
        
        // Sort by timestamp, newest first
        result.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        return result;
    }
    
    /**
     * Get only active incidents
     * @returns {Array} Active incidents
     */
    getActiveIncidents() {
        return Object.values(this.activeIncidents).sort(
            (a, b) => {
                // Sort by priority first (high to low)
                const priorityOrder = { high: 0, medium: 1, low: 2, info: 3 };
                if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
                    return priorityOrder[a.priority] - priorityOrder[b.priority];
                }
                
                // Then by timestamp (newest first)
                return new Date(b.timestamp) - new Date(a.timestamp);
            }
        );
    }
    
    /**
     * Get incident count by priority
     * @returns {Object} Count by priority level
     */
    getIncidentCounts() {
        const result = {
            high: 0,
            medium: 0,
            low: 0,
            info: 0,
            total: 0,
            active: this.activeIncidentCounter
        };
        
        // Count active incidents by priority
        Object.values(this.activeIncidents).forEach(incident => {
            result[incident.priority]++;
            result.total++;
        });
        
        return result;
    }
    
    /**
     * Create an incident from threat detector data
     * @param {Object} threatData - Threat data from threat detector
     * @returns {string} Incident ID
     */
    createFromThreatData(threatData) {
        // Map threat level to incident score (0-100)
        const score = threatData.threatLevel;
        
        // Determine primary source of the threat
        let source = 'unknown';
        let description = 'Unknown threat detected';
        
        if (threatData.factors) {
            // Find the factor with the highest contribution
            const factors = Object.keys(threatData.factors);
            if (factors.length > 0) {
                // Sort factors by contribution value (highest first)
                factors.sort((a, b) => threatData.factors[b] - threatData.factors[a]);
                source = factors[0]; // Primary factor
                
                // Create a human-readable description based on the factors
                if (source === 'acceleration') {
                    description = 'Unusual movement pattern detected';
                    if (threatData.movementType === 'running') {
                        description = 'Running detected';
                    } else if (threatData.movementType === 'erratic') {
                        description = 'Erratic movement detected';
                    }
                } else if (source === 'heartRate') {
                    description = 'Elevated heart rate detected';
                } else if (source === 'audio') {
                    description = 'Unusual ambient audio detected';
                }
            }
        }
        
        // Log the incident
        return this.logIncident({
            type: 'threat_detected',
            score: score,
            source: source,
            description: description,
            data: threatData
        });
    }
    
    /**
     * Create an incident from anomaly detection
     * @param {Object} anomalyData - Anomaly data from predictive learning
     * @returns {string} Incident ID
     */
    createFromAnomalyData(anomalyData) {
        // Map anomaly score to incident score (0-100)
        const score = anomalyData.anomalyScore;
        
        // Determine source of the anomaly
        let source = 'behavioral_pattern';
        let description = 'Behavioral anomaly detected';
        
        if (anomalyData.components) {
            if (anomalyData.components.movementAnomaly) {
                source = 'movement_pattern';
                description = 'Unusual movement pattern for this time/location';
            } else if (anomalyData.components.heartRateAnomaly) {
                source = 'heart_rate_pattern';
                description = 'Unusual heart rate for this time/location';
            } else if (anomalyData.components.audioAnomaly) {
                source = 'audio_pattern';
                description = 'Unusual audio pattern for this time/location';
            }
        }
        
        // Log the incident
        return this.logIncident({
            type: 'anomaly_detected',
            score: score,
            source: source,
            description: description,
            data: anomalyData
        });
    }
    
    /**
     * Create an incident from a manually triggered SOS
     * @param {string} triggerMethod - How the SOS was triggered
     * @returns {string} Incident ID
     */
    createFromSOSTrigger(triggerMethod) {
        // Manual SOS triggers are always high priority
        const score = 90;
        
        // Determine source based on trigger method
        let source, description;
        
        switch (triggerMethod.toLowerCase()) {
            case 'power button':
                source = 'power_button';
                description = 'SOS triggered by power button sequence';
                break;
            case 'shake':
                source = 'shake_gesture';
                description = 'SOS triggered by shake gesture';
                break;
            case 'tilt':
                source = 'tilt_gesture';
                description = 'SOS triggered by tilt gesture';
                break;
            default:
                if (triggerMethod.toLowerCase().includes('voice')) {
                    source = 'voice_command';
                    description = `SOS triggered by voice command: "${triggerMethod.split('"')[1]}"`;
                } else {
                    source = 'manual';
                    description = `SOS manually triggered: ${triggerMethod}`;
                }
        }
        
        // Log the incident
        return this.logIncident({
            type: 'sos_triggered',
            score: score,
            source: source,
            description: description,
            data: {
                triggerMethod: triggerMethod,
                message: this.configManager.getAlertMessage()
            }
        });
    }
    
    /**
     * Trigger the SOS system from an incident
     * @param {Object} incident - Incident data
     */
    triggerSOS(incident) {
        // Use the alert service to send the SOS
        this.alertService.sendSOSAlert(incident.source, {
            incidentId: incident.id,
            priority: incident.priority,
            description: incident.description,
            score: incident.score
        })
        .then(result => {
            // Update the incident with the alert result
            this.updateIncident(incident.id, {
                alertSent: true,
                alertResult: result
            });
        })
        .catch(error => {
            // Update the incident with the error
            this.updateIncident(incident.id, {
                alertSent: false,
                alertError: error.message
            });
        });
    }
    
    /**
     * Clear all incident history (active incidents will not be removed)
     */
    clearHistory() {
        // Keep only active incidents
        this.incidents = this.incidents.filter(inc => inc.status === 'active');
        this.saveIncidents();
        this.notifyListeners('history_cleared', {});
    }
    
    /**
     * Dispose of the alert priority system
     */
    dispose() {
        // Clear the escalation interval
        if (this.escalationInterval) {
            clearInterval(this.escalationInterval);
            this.escalationInterval = null;
        }
        
        // Save current incidents
        this.saveIncidents();
        
        // Clear listeners
        this.listeners = [];
    }
}

/**
 * Create an alert priority system
 * @param {ConfigManager} configManager - Configuration manager
 * @param {AlertService} alertService - Alert service
 * @returns {AlertPrioritySystem} Alert priority system
 */
function createAlertPrioritySystem(configManager, alertService) {
    return new AlertPrioritySystem(configManager, alertService);
}