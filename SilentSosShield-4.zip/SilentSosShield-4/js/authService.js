/**
 * Authentication Service
 * Handles user login, registration, and session management
 */
class AuthService {
    constructor(apiService) {
        this.apiService = apiService;
        this.currentUser = null;
        this.initialized = false;
        
        // Attempt to load user from local storage
        this.loadUserFromStorage();
    }
    
    /**
     * Load user data from localStorage if available
     * @private
     */
    loadUserFromStorage() {
        try {
            const userData = localStorage.getItem('sosUser');
            if (userData) {
                this.currentUser = JSON.parse(userData);
                console.log('User loaded from storage:', this.currentUser.username);
            }
        } catch (error) {
            console.error('Failed to load user data from storage:', error);
            this.currentUser = null;
            localStorage.removeItem('sosUser');
        }
    }
    
    /**
     * Save user data to localStorage
     * @param {Object} user - User data to save
     * @private
     */
    saveUserToStorage(user) {
        if (user) {
            localStorage.setItem('sosUser', JSON.stringify(user));
        } else {
            localStorage.removeItem('sosUser');
        }
    }
    
    /**
     * Register a new user
     * @param {string} username - Username
     * @param {string} password - Password
     * @param {string} email - Email (optional)
     * @returns {Promise<Object>} Registered user
     */
    async register(username, password, email = null) {
        try {
            const userData = { username, password };
            if (email) {
                userData.email = email;
            }
            
            console.log('Registering with data:', userData);
            const response = await fetch(`${this.apiService.baseUrl}/api/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });
            console.log('Register response status:', response.status);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Registration failed');
            }
            
            const user = await response.json();
            
            // Don't automatically log in - user should log in separately
            return user;
        } catch (error) {
            console.error('Registration error:', error);
            throw error;
        }
    }
    
    /**
     * Login user
     * @param {string} username - Username
     * @param {string} password - Password
     * @returns {Promise<Object>} Logged in user
     */
    async login(username, password) {
        try {
            console.log('Logging in with username:', username);
            const response = await fetch(`${this.apiService.baseUrl}/api/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            console.log('Login response status:', response.status);
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Login failed');
            }
            
            const user = await response.json();
            
            // Store user data
            this.currentUser = user;
            this.saveUserToStorage(user);
            
            return user;
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }
    
    /**
     * Logout the current user
     */
    logout() {
        this.currentUser = null;
        this.saveUserToStorage(null);
    }
    
    /**
     * Check if user is logged in
     * @returns {boolean} True if logged in
     */
    isLoggedIn() {
        return !!this.currentUser;
    }
    
    /**
     * Get current user data
     * @returns {Object|null} Current user or null if not logged in
     */
    getCurrentUser() {
        return this.currentUser;
    }
}

// Initialize auth service when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Create API service if not already available
    if (!window.apiService) {
        window.apiService = new ApiService();
    }
    
    // Create auth service
    window.authService = new AuthService(window.apiService);
    
    // Get DOM elements
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const loginTab = document.getElementById('login-tab');
    const registerTab = document.getElementById('register-tab');
    const loginFormDiv = document.getElementById('login-form');
    const registerFormDiv = document.getElementById('register-form');
    const authAlert = document.getElementById('authAlert');
    
    // Function to show authentication alert
    function showAuthAlert(message, type = 'danger') {
        authAlert.textContent = message;
        authAlert.className = `alert auth-alert alert-${type}`;
        authAlert.style.display = 'block';
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            authAlert.style.display = 'none';
        }, 5000);
    }
    
    // Tab click handlers
    loginTab.addEventListener('click', function() {
        loginFormDiv.classList.add('active');
        registerFormDiv.classList.remove('active');
    });
    
    registerTab.addEventListener('click', function() {
        loginFormDiv.classList.remove('active');
        registerFormDiv.classList.add('active');
    });
    
    // Login form submit handler
    if (loginForm) {
        loginForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            
            const username = document.getElementById('loginUsername').value;
            const password = document.getElementById('loginPassword').value;
            
            try {
                // Show loading state
                const submitBtn = loginForm.querySelector('button[type="submit"]');
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...';
                submitBtn.disabled = true;
                
                // Attempt login
                await authService.login(username, password);
                
                // Redirect to main page on success
                window.location.href = 'index.html';
            } catch (error) {
                // Show error message
                showAuthAlert(`Login failed: ${error.message}`);
                
                // Reset form button
                const submitBtn = loginForm.querySelector('button[type="submit"]');
                submitBtn.innerHTML = 'Login';
                submitBtn.disabled = false;
            }
        });
    }
    
    // Registration form submit handler
    if (registerForm) {
        registerForm.addEventListener('submit', async function(event) {
            event.preventDefault();
            
            const username = document.getElementById('registerUsername').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validate passwords match
            if (password !== confirmPassword) {
                showAuthAlert('Passwords do not match');
                return;
            }
            
            try {
                // Show loading state
                const submitBtn = registerForm.querySelector('button[type="submit"]');
                const originalBtnText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Registering...';
                submitBtn.disabled = true;
                
                // Attempt registration
                await authService.register(username, password, email);
                
                // Show success and switch to login tab
                showAuthAlert('Registration successful! Please log in.', 'success');
                loginTab.click();
                
                // Reset form
                registerForm.reset();
                
                // Reset form button
                submitBtn.innerHTML = 'Register';
                submitBtn.disabled = false;
            } catch (error) {
                // Show error message
                showAuthAlert(`Registration failed: ${error.message}`);
                
                // Reset form button
                const submitBtn = registerForm.querySelector('button[type="submit"]');
                submitBtn.innerHTML = 'Register';
                submitBtn.disabled = false;
            }
        });
    }
    
    // Check if user is already logged in
    if (authService.isLoggedIn()) {
        // If on login page, redirect to main page
        if (window.location.pathname.includes('login.html')) {
            window.location.href = 'index.html';
        }
    } else {
        // If not on login page, redirect to login page
        if (!window.location.pathname.includes('login.html')) {
            window.location.href = 'login.html';
        }
    }
});