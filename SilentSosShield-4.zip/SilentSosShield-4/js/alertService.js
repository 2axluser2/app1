/**
 * Alert Service
 * Handles sending SOS alerts to emergency contacts
 */
class AlertService {
    constructor(configManager, contactManager) {
        this.configManager = configManager;
        this.contactManager = contactManager;
        this.alertHistory = [];
        
        // Load alert history from API if available
        this.loadAlertHistoryFromAPI();
    }
    
    /**
     * Attempt to load alert history from the API server
     * @private
     */
    async loadAlertHistoryFromAPI() {
        try {
            // If API server is connected, fetch alert history
            if (typeof apiService !== 'undefined') {
                const history = await apiService.getAlertHistory();
                if (history && history.length > 0) {
                    this.alertHistory = history;
                    console.log('Loaded alert history from API server');
                }
            }
        } catch (error) {
            console.error('Failed to load alert history from API:', error);
            // Fallback to empty history (already set in constructor)
        }
    }

    /**
     * Sends SOS alert to all emergency contacts
     * @param {string} triggerType - How the alert was triggered (power_button, shake, tilt)
     * @returns {Promise<Object>} Result of the alert operation
     */
    async sendSOSAlert(triggerType = 'power_button') {
        const message = this.configManager.getAlertMessage();
        const contacts = this.contactManager.getContacts();
        
        if (contacts.length === 0) {
            return {
                success: false,
                error: "No emergency contacts configured",
                timestamp: new Date().toISOString()
            };
        }

        try {
            // Attempt to send alert via API server
            if (typeof apiService !== 'undefined') {
                try {
                    // Get location if available (in a real app)
                    let locationLat = null;
                    let locationLong = null;
                    
                    // In a production app, we'd get the location:
                    // if (navigator.geolocation) {
                    //     const position = await new Promise((resolve, reject) => {
                    //         navigator.geolocation.getCurrentPosition(resolve, reject);
                    //     });
                    //     locationLat = position.coords.latitude;
                    //     locationLong = position.coords.longitude;
                    // }
                    
                    // Create alert data for API
                    const alertData = {
                        message: message,
                        triggerType: triggerType,
                        locationLat: locationLat,
                        locationLong: locationLong,
                        contactIds: contacts.map(c => c.id)
                    };
                    
                    // Send alert to API server
                    const response = await apiService.sendAlert(alertData);
                    
                    // Update local history
                    if (response) {
                        this.alertHistory.push(response);
                        
                        return {
                            success: true,
                            alertId: response.id,
                            sentTo: response.recipients ? response.recipients.length : contacts.length,
                            message: message,
                            timestamp: response.created_at || new Date().toISOString()
                        };
                    }
                } catch (apiError) {
                    console.error('API alert send failed, falling back to local:', apiError);
                    // Continue with local alert if API fails
                }
            }
            
            // Fallback: Create local alert record if API is unavailable
            const alertRecord = {
                id: Date.now().toString(),
                message: message,
                trigger_type: triggerType,
                recipients: contacts.map(c => ({ id: c.id, name: c.name, phone: c.phone })),
                created_at: new Date().toISOString(),
                success: true
            };
            
            // Add to local history
            this.alertHistory.push(alertRecord);
            
            return {
                success: true,
                alertId: alertRecord.id,
                sentTo: contacts.length,
                message: message,
                timestamp: alertRecord.created_at
            };
            
        } catch (error) {
            console.error('Error sending alert:', error);
            return {
                success: false,
                error: error.message || "Failed to send alert",
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Gets the last sent alert
     * @returns {Object|null} Last alert or null if none
     */
    getLastAlert() {
        if (this.alertHistory.length === 0) {
            return null;
        }
        return this.alertHistory[this.alertHistory.length - 1];
    }

    /**
     * Gets all sent alerts
     * @returns {Array} Array of alert records
     */
    getAlertHistory() {
        return [...this.alertHistory];
    }

    /**
     * Clears alert history
     */
    async clearHistory() {
        this.alertHistory = [];
        
        // In a full implementation, we'd also clear server history
        // await apiService.clearAlertHistory();
    }
}

// Create a singleton instance with the required dependencies
const alertService = new AlertService(configManager, contactManager);
