/**
 * API Service
 * Handles communication with the backend server for persistent storage
 */
class ApiService {
    constructor() {
        // API base URL - this should point to the server we set up
        this.baseUrl = window.location.protocol + '//' + window.location.hostname + ':5001';
        console.log('API base URL:', this.baseUrl);
        
        // User data - will be set after login
        this.currentUserId = null;
        this.currentUsername = null;
        
        // Initial check for server connectivity
        this.checkServerStatus();
    }
    
    /**
     * Set current user information
     * @param {Object} user - User information
     */
    setCurrentUser(user) {
        if (user && user.id) {
            this.currentUserId = user.id;
            this.currentUsername = user.username;
        } else {
            this.currentUserId = null;
            this.currentUsername = null;
        }
    }
    
    /**
     * Check if the API server is reachable
     * @returns {Promise<boolean>} Whether the server is available
     */
    async checkServerStatus() {
        try {
            const response = await fetch(`${this.baseUrl}/status`);
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('API server is available:', data);
            return true;
        } catch (error) {
            console.error('API server is not available:', error);
            return false;
        }
    }
    
    /**
     * Get a user's information by username
     * @param {string} username - Username to look up
     * @returns {Promise<Object>} User information
     */
    async getUserByUsername(username) {
        try {
            const response = await fetch(`${this.baseUrl}/api/users/${username}`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error fetching user:', error);
            throw error;
        }
    }
    
    /**
     * Get all contacts for the current user
     * @returns {Promise<Array>} List of contacts
     */
    async getContacts() {
        try {
            if (!this.currentUserId) {
                throw new Error('No user logged in');
            }
            
            const response = await fetch(`${this.baseUrl}/api/users/${this.currentUserId}/contacts`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error fetching contacts:', error);
            // Return empty array on error for graceful degradation
            return [];
        }
    }
    
    /**
     * Add a new contact
     * @param {Object} contact - Contact object with name and phone
     * @returns {Promise<Object>} Created contact
     */
    async addContact(contact) {
        try {
            const response = await fetch(`${this.baseUrl}/api/users/${this.currentUserId}/contacts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(contact),
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error adding contact:', error);
            throw error;
        }
    }
    
    /**
     * Remove a contact
     * @param {string} contactId - ID of contact to remove
     * @returns {Promise<boolean>} Success status
     */
    async removeContact(contactId) {
        try {
            const response = await fetch(`${this.baseUrl}/api/contacts/${contactId}`, {
                method: 'DELETE',
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return true;
        } catch (error) {
            console.error('Error removing contact:', error);
            return false;
        }
    }
    
    /**
     * Get alert history
     * @returns {Promise<Array>} List of alert records
     */
    async getAlertHistory() {
        try {
            const response = await fetch(`${this.baseUrl}/api/users/${this.currentUserId}/alerts`);
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error fetching alert history:', error);
            // Return empty array on error for graceful degradation
            return [];
        }
    }
    
    /**
     * Send SOS alert
     * @param {Object} alert - Alert data including message and trigger type
     * @returns {Promise<Object>} Created alert
     */
    async sendAlert(alert) {
        try {
            const response = await fetch(`${this.baseUrl}/api/users/${this.currentUserId}/alerts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: alert.message,
                    triggerType: alert.triggerType,
                    locationLat: alert.locationLat,
                    locationLong: alert.locationLong,
                    contactIds: alert.contactIds,
                }),
            });
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status} ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error sending alert:', error);
            throw error;
        }
    }
}

// Export a singleton instance
const apiService = new ApiService();